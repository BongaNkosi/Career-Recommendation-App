package com.career.recommendation_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CareerRecommendationBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}

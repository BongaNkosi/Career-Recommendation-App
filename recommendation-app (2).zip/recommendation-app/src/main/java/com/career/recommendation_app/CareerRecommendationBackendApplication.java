package com.career.recommendation_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CareerRecommendationBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(CareerRecommendationBackendApplication.class, args);
	}

}

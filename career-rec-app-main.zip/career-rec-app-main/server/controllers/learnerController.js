const bcrypt = require('bcryptjs');
const { User, LearnerMark, Recommendation } = require('../models');
const { asyncHandler, createError } = require('../middleware/errorHandler');
const { Op } = require('sequelize');

exports.getAll = asyncHandler(async (req, res) => {
  const { province, search } = req.query;
  const where = { role: 'learner' };
  if (province) where.province = province;
  if (search) {
    where[Op.or] = [
      { first_name: { [Op.like]: `%${search}%` } },
      { last_name:  { [Op.like]: `%${search}%` } },
      { email:      { [Op.like]: `%${search}%` } },
    ];
  }
  const learners = await User.findAll({
    where, order: [['created_at','DESC']],
    attributes: ['user_id','first_name','last_name','email','province','gender','date_of_birth','is_active','created_at'],
  });
  res.json(learners);
});

exports.getOne = asyncHandler(async (req, res) => {
  const learner = await User.findOne({
    where: { user_id: req.params.id, role: 'learner' },
    attributes: { exclude: ['password_hash'] },
  });
  if (!learner) throw createError(404, 'Learner not found.');
  res.json(learner);
});

exports.create = asyncHandler(async (req, res) => {
  const { firstName, lastName, email, password, province, gender, dateOfBirth } = req.body;
  if (!firstName?.trim() || !lastName?.trim() || !email?.trim() || !password) {
    throw createError(400, 'First name, last name, email and password are required.');
  }
  const existing = await User.findOne({ where: { email: email.toLowerCase().trim() } });
  if (existing) throw createError(409, 'A user with this email already exists.');

  const password_hash = await bcrypt.hash(password, 12);
  const learner = await User.create({
    first_name: firstName.trim(), last_name: lastName.trim(),
    email: email.toLowerCase().trim(), password_hash,
    role: 'learner', province: province || null,
    gender: gender || null, date_of_birth: dateOfBirth || null,
  });
  res.status(201).json({ message: 'Learner created.', userId: learner.user_id });
});

exports.update = asyncHandler(async (req, res) => {
  const learner = await User.findOne({ where: { user_id: req.params.id, role: 'learner' } });
  if (!learner) throw createError(404, 'Learner not found.');
  const { firstName, lastName, email, province, gender, dateOfBirth, isActive } = req.body;
  if (!firstName?.trim() || !lastName?.trim() || !email?.trim()) {
    throw createError(400, 'First name, last name and email are required.');
  }
  await learner.update({
    first_name: firstName.trim(), last_name: lastName.trim(),
    email: email.toLowerCase().trim(), province: province || null,
    gender: gender || null, date_of_birth: dateOfBirth || null,
    is_active: isActive !== undefined ? isActive : learner.is_active,
  });
  res.json({ message: 'Learner updated.' });
});

exports.remove = asyncHandler(async (req, res) => {
  const learner = await User.findOne({ where: { user_id: req.params.id, role: 'learner' } });
  if (!learner) throw createError(404, 'Learner not found.');
  // Cascade delete
  await Recommendation.destroy({ where: { user_id: req.params.id } });
  await LearnerMark.destroy({ where: { user_id: req.params.id } });
  await learner.destroy();
  res.json({ message: 'Learner and all associated data deleted.' });
});

// Learner's own profile
exports.getProfile = asyncHandler(async (req, res) => {
  const user = await User.findByPk(req.user.userId, {
    attributes: ['user_id','first_name','last_name','email','province','gender','date_of_birth','profile_image','created_at'],
  });
  if (!user) throw createError(404, 'Profile not found.');
  res.json(user);
});

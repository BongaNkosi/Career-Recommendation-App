const { Institution, Programme } = require('../models');
const { asyncHandler, createError } = require('../middleware/errorHandler');
const { Op } = require('sequelize');

exports.getAll = asyncHandler(async (req, res) => {
  const { search, province, type } = req.query;
  const where = { is_active: true };
  if (province) where.province = province;
  if (type)     where.type     = type;
  if (search)   where.name     = { [Op.like]: `%${search}%` };

  const institutions = await Institution.findAll({
    where,
    order: [['name', 'ASC']],
    attributes: { exclude: [] },
  });
  res.json(institutions);
});

exports.getOne = asyncHandler(async (req, res) => {
  const institution = await Institution.findByPk(req.params.id, {
    include: [{ model: Programme, as: 'programmes', where: { is_active: true }, required: false }],
  });
  if (!institution) throw createError(404, 'Institution not found.');
  res.json(institution);
});

exports.create = asyncHandler(async (req, res) => {
  const { name, abbreviation, type, province, city, website, logo_url, description } = req.body;
  if (!name?.trim() || !abbreviation?.trim() || !type || !province || !city?.trim()) {
    throw createError(400, 'Name, abbreviation, type, province and city are required.');
  }
  const institution = await Institution.create({
    name: name.trim(), abbreviation: abbreviation.trim().toUpperCase(),
    type, province, city: city.trim(), website: website || null,
    logo_url: logo_url || null, description: description || null,
  });
  res.status(201).json(institution);
});

exports.update = asyncHandler(async (req, res) => {
  const institution = await Institution.findByPk(req.params.id);
  if (!institution) throw createError(404, 'Institution not found.');

  const { name, abbreviation, type, province, city, website, logo_url, description, is_active } = req.body;
  if (!name?.trim() || !type || !province || !city?.trim()) {
    throw createError(400, 'Name, type, province and city are required.');
  }
  await institution.update({
    name: name.trim(), abbreviation: (abbreviation || '').trim().toUpperCase(),
    type, province, city: city.trim(), website: website || null,
    logo_url: logo_url || null, description: description || null,
    is_active: is_active !== undefined ? is_active : institution.is_active,
  });
  res.json(institution);
});

exports.remove = asyncHandler(async (req, res) => {
  const institution = await Institution.findByPk(req.params.id);
  if (!institution) throw createError(404, 'Institution not found.');
  try {
    await institution.destroy();
    res.json({ message: 'Institution deleted.', id: req.params.id });
  } catch (err) {
    if (err.name === 'SequelizeForeignKeyConstraintError') {
      throw createError(409, 'Cannot delete: this institution has associated programmes. Remove those first.');
    }
    throw err;
  }
});

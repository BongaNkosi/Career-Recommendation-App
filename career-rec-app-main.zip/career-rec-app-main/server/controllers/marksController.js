const { LearnerMark, Subject, User } = require('../models');
const { asyncHandler, createError } = require('../middleware/errorHandler');

/** Convert a percentage mark to South African APS points. */
const markToAPS = (mark) => {
  if (mark >= 80) return 7;
  if (mark >= 70) return 6;
  if (mark >= 60) return 5;
  if (mark >= 50) return 4;
  if (mark >= 40) return 3;
  if (mark >= 30) return 2;
  return 1;
};

const subjectInclude = { model: Subject, as: 'subject', attributes: ['name','code','subject_type'] };
const userInclude    = { model: User,    as: 'user',    attributes: ['user_id','first_name','last_name','email'] };

exports.getSubjects = asyncHandler(async (req, res) => {
  const subjects = await Subject.findAll({ order: [['subject_type','ASC'],['name','ASC']] });
  res.json(subjects);
});

exports.getAll = asyncHandler(async (req, res) => {
  const isAdmin = req.user.role === 'admin';
  const where   = isAdmin ? {} : { user_id: req.user.userId };
  const include = isAdmin ? [subjectInclude, userInclude] : [subjectInclude];

  const marks = await LearnerMark.findAll({
    where, include,
    order: [['academic_year','DESC'],['created_at','DESC']],
  });

  // Attach APS points
  const result = marks.map(m => ({
    ...m.toJSON(),
    aps_points: markToAPS(parseFloat(m.mark)),
  }));
  res.json(result);
});

exports.getLearnerMarks = asyncHandler(async (req, res) => {
  const marks = await LearnerMark.findAll({
    where: { user_id: req.params.userId },
    include: [subjectInclude],
    order: [['academic_year','DESC'],['created_at','DESC']],
  });
  const result = marks.map(m => ({ ...m.toJSON(), aps_points: markToAPS(parseFloat(m.mark)) }));
  res.json(result);
});

exports.create = asyncHandler(async (req, res) => {
  const { user_id, subject_id, mark, grade, academic_year } = req.body;
  const targetUserId = req.user.role === 'admin' ? (user_id || req.user.userId) : req.user.userId;

  if (!subject_id || mark === undefined || mark === null || !academic_year) {
    throw createError(400, 'Subject, mark and academic year are required.');
  }
  const numMark = parseFloat(mark);
  if (isNaN(numMark) || numMark < 0 || numMark > 100) {
    throw createError(400, 'Mark must be a number between 0 and 100.');
  }

  const subject = await Subject.findByPk(subject_id);
  if (!subject) throw createError(400, 'Selected subject does not exist.');

  // Upsert: if same user+subject+year exists, update it
  const [markRecord, created] = await LearnerMark.findOrCreate({
    where: { user_id: targetUserId, subject_id, academic_year },
    defaults: { mark: numMark, grade: grade || 12 },
  });
  if (!created) {
    await markRecord.update({ mark: numMark, grade: grade || 12 });
  }

  res.status(created ? 201 : 200).json({
    message: created ? 'Mark saved.' : 'Mark updated.',
    mark: { ...markRecord.toJSON(), aps_points: markToAPS(numMark) },
  });
});

exports.update = asyncHandler(async (req, res) => {
  const markRecord = await LearnerMark.findByPk(req.params.id);
  if (!markRecord) throw createError(404, 'Mark record not found.');
  if (req.user.role === 'learner' && markRecord.user_id !== req.user.userId) {
    throw createError(403, 'You can only edit your own marks.');
  }

  const { mark, grade, academic_year } = req.body;
  const numMark = parseFloat(mark);
  if (isNaN(numMark) || numMark < 0 || numMark > 100) {
    throw createError(400, 'Mark must be between 0 and 100.');
  }
  await markRecord.update({ mark: numMark, grade: grade || markRecord.grade, academic_year: academic_year || markRecord.academic_year });
  res.json({ message: 'Mark updated.', mark: { ...markRecord.toJSON(), aps_points: markToAPS(numMark) } });
});

exports.remove = asyncHandler(async (req, res) => {
  const markRecord = await LearnerMark.findByPk(req.params.id);
  if (!markRecord) throw createError(404, 'Mark not found.');
  if (req.user.role === 'learner' && markRecord.user_id !== req.user.userId) {
    throw createError(403, 'You can only delete your own marks.');
  }
  await markRecord.destroy();
  res.json({ message: 'Mark deleted.' });
});

// Export helper for use in recommendations
exports.markToAPS = markToAPS;
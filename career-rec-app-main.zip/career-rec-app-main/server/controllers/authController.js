const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const { User } = require('../models');
const { asyncHandler, createError } = require('../middleware/errorHandler');

/** Sign a JWT for the given user payload. */
const signToken = (user) =>
  jwt.sign(
    { userId: user.user_id, email: user.email, role: user.role, firstName: user.first_name },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
  );

/** Safe user payload (no password_hash). */
const safeUser = (user) => ({
  userId:    user.user_id,
  firstName: user.first_name,
  lastName:  user.last_name,
  email:     user.email,
  role:      user.role,
  province:  user.province,
  gender:    user.gender,
  profileImage: user.profile_image,
});

// ─── POST /api/auth/register ──────────────────────────────────────────────────
exports.register = asyncHandler(async (req, res) => {
  const { firstName, lastName, email, password, province, gender, dateOfBirth } = req.body;

  if (!firstName?.trim() || !lastName?.trim() || !email?.trim() || !password) {
    throw createError(400, 'First name, last name, email and password are required.');
  }
  if (password.length < 8) {
    throw createError(400, 'Password must be at least 8 characters.');
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw createError(400, 'Please provide a valid email address.');
  }

  const existing = await User.findOne({ where: { email: email.toLowerCase().trim() } });
  if (existing) throw createError(409, 'An account with this email already exists.');

  const password_hash = await bcrypt.hash(password, 12);

  const user = await User.create({
    first_name:    firstName.trim(),
    last_name:     lastName.trim(),
    email:         email.toLowerCase().trim(),
    password_hash,
    role:          'learner',
    province:      province || null,
    gender:        gender   || null,
    date_of_birth: dateOfBirth || null,
  });

  // Auto-authenticate: return token immediately so frontend can log in
  const token = signToken(user);

  res.status(201).json({ token, user: safeUser(user) });
});

// ─── POST /api/auth/login ─────────────────────────────────────────────────────
exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email?.trim() || !password) {
    throw createError(400, 'Email and password are required.');
  }

  // Explicitly include password_hash for comparison
  const user = await User.scope('withPassword').findOne({
    where: { email: email.toLowerCase().trim(), is_active: true },
  });

  if (!user) throw createError(401, 'Invalid email or password.');

  const match = await bcrypt.compare(password, user.password_hash);
  if (!match)  throw createError(401, 'Invalid email or password.');

  const token = signToken(user);
  res.json({ token, user: safeUser(user) });
});

// ─── GET /api/auth/me ─────────────────────────────────────────────────────────
exports.getMe = asyncHandler(async (req, res) => {
  const user = await User.findByPk(req.user.userId);
  if (!user) throw createError(404, 'User not found.');
  res.json(safeUser(user));
});

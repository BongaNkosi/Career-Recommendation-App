const { Recommendation, Programme, Institution, LearnerMark, User } = require('../models');
const { asyncHandler, createError } = require('../middleware/errorHandler');
const { markToAPS } = require('./marksController');
const { sequelize } = require('../config/db');

const programmeInclude = {
  model: Programme, as: 'programme',
  attributes: ['name','faculty','aps_requirement','duration_years','field','description'],
  include: [{ model: Institution, as: 'institution', attributes: ['name','abbreviation','province','logo_url','website'] }],
};

exports.getAll = asyncHandler(async (req, res) => {
  const isAdmin = req.user.role === 'admin';
  const where   = isAdmin ? {} : { user_id: req.user.userId };
  const include = isAdmin
    ? [programmeInclude, { model: User, as: 'user', attributes: ['first_name','last_name','email'] }]
    : [programmeInclude];

  const recs = await Recommendation.findAll({
    where, include, order: [['match_percentage','DESC'],['created_at','DESC']],
  });
  res.json(recs);
});

/**
 * Generate recommendations in Node.js:
 * 1. Fetch learner marks for given year
 * 2. Compute APS (top 6 subjects excl. Life Orientation)
 * 3. Find eligible programmes where aps_requirement <= learner APS
 * 4. Calculate match % = (aps_requirement / learner_aps) * 100
 * 5. Delete old recommendations for same user+year, insert new ones
 */
exports.generate = asyncHandler(async (req, res) => {
  const userId      = req.user.role === 'admin' ? (req.body.user_id || req.user.userId) : req.user.userId;
  const academicYear = parseInt(req.body.academic_year) || new Date().getFullYear();

  // Fetch marks
  const marks = await LearnerMark.findAll({
    where: { user_id: userId, academic_year: academicYear },
    include: [{ model: require('../models').Subject, as: 'subject', attributes: ['name','subject_type'] }],
  });

  if (!marks.length) {
    throw createError(400, `No marks found for ${academicYear}. Please enter your subject marks first.`);
  }

  // Calculate APS: top 6, exclude Life Orientation
  const eligible = marks
    .filter(m => !m.subject?.name?.toLowerCase().includes('life orientation'))
    .map(m => ({ mark: parseFloat(m.mark), aps: markToAPS(parseFloat(m.mark)) }))
    .sort((a,b) => b.aps - a.aps)
    .slice(0, 6);

  const apsScore = eligible.reduce((sum, m) => sum + m.aps, 0);

  // Find eligible programmes
  const programmes = await Programme.findAll({
    where: { is_active: true, aps_requirement: { [require('sequelize').Op.lte]: apsScore } },
  });

  if (!programmes.length) {
    return res.json({
      message: `Your APS score is ${apsScore}. No matching programmes found yet — keep improving your marks!`,
      apsScore, recommendationCount: 0,
    });
  }

  // Delete old recommendations for this user+year
  await Recommendation.destroy({ where: { user_id: userId, academic_year: academicYear } });

  // Create new recommendations
  const toInsert = programmes.map(p => ({
    user_id: userId,
    programme_id: p.programme_id,
    aps_score: apsScore,
    match_percentage: Math.min(100, parseFloat(((p.aps_requirement / apsScore) * 100).toFixed(2))),
    status: 'generated',
    academic_year: academicYear,
  }));

  await Recommendation.bulkCreate(toInsert);

  res.json({
    message: `Generated ${toInsert.length} recommendation(s) based on your APS score of ${apsScore}.`,
    apsScore,
    recommendationCount: toInsert.length,
  });
});

exports.updateStatus = asyncHandler(async (req, res) => {
  const allowed = ['generated','viewed','applied','accepted','rejected'];
  const { status } = req.body;
  if (!allowed.includes(status)) throw createError(400, 'Invalid status value.');

  const rec = await Recommendation.findByPk(req.params.id);
  if (!rec) throw createError(404, 'Recommendation not found.');
  if (req.user.role === 'learner' && rec.user_id !== req.user.userId) {
    throw createError(403, 'You can only update your own recommendations.');
  }
  await rec.update({ status });
  res.json({ message: 'Status updated.', status });
});

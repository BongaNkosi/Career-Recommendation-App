const { Programme, Institution } = require('../models');
const { asyncHandler, createError } = require('../middleware/errorHandler');
const { Op } = require('sequelize');

const withInstitution = { model: Institution, as: 'institution', attributes: ['name','abbreviation','province','city','logo_url','website'] };

exports.getAll = asyncHandler(async (req, res) => {
  const { field, institution_id, min_aps, max_aps, search } = req.query;
  const where = { is_active: true };
  if (field)          where.field          = field;
  if (institution_id) where.institution_id = institution_id;
  if (search)         where.name           = { [Op.like]: `%${search}%` };
  if (min_aps || max_aps) {
    where.aps_requirement = {};
    if (min_aps) where.aps_requirement[Op.gte] = parseInt(min_aps);
    if (max_aps) where.aps_requirement[Op.lte] = parseInt(max_aps);
  }
  const programmes = await Programme.findAll({
    where, include: [withInstitution], order: [['aps_requirement','DESC'],['name','ASC']],
  });
  res.json(programmes);
});

exports.getOne = asyncHandler(async (req, res) => {
  const programme = await Programme.findByPk(req.params.id, { include: [withInstitution] });
  if (!programme) throw createError(404, 'Programme not found.');
  res.json(programme);
});

exports.create = asyncHandler(async (req, res) => {
  const { name, faculty, institution_id, aps_requirement, duration_years, nqf_level, field, description } = req.body;
  if (!name?.trim() || !institution_id || !aps_requirement || !duration_years || !field) {
    throw createError(400, 'Name, institution, APS requirement, duration and field are required.');
  }
  if (aps_requirement < 1 || aps_requirement > 42) {
    throw createError(400, 'APS requirement must be between 1 and 42.');
  }
  const inst = await Institution.findByPk(institution_id);
  if (!inst) throw createError(400, 'Selected institution does not exist.');

  const programme = await Programme.create({
    name: name.trim(), faculty: faculty || null, institution_id,
    aps_requirement, duration_years, nqf_level: nqf_level || 7,
    field, description: description || null,
  });
  const created = await Programme.findByPk(programme.programme_id, { include: [withInstitution] });
  res.status(201).json(created);
});

exports.update = asyncHandler(async (req, res) => {
  const programme = await Programme.findByPk(req.params.id);
  if (!programme) throw createError(404, 'Programme not found.');
  const { name, faculty, institution_id, aps_requirement, duration_years, nqf_level, field, description, is_active } = req.body;
  if (!name?.trim() || !institution_id || !aps_requirement || !duration_years || !field) {
    throw createError(400, 'Name, institution, APS requirement, duration and field are required.');
  }
  await programme.update({
    name: name.trim(), faculty: faculty || null, institution_id,
    aps_requirement, duration_years, nqf_level: nqf_level || 7,
    field, description: description || null,
    is_active: is_active !== undefined ? is_active : programme.is_active,
  });
  const updated = await Programme.findByPk(programme.programme_id, { include: [withInstitution] });
  res.json(updated);
});

exports.remove = asyncHandler(async (req, res) => {
  const programme = await Programme.findByPk(req.params.id);
  if (!programme) throw createError(404, 'Programme not found.');
  await programme.destroy();
  res.json({ message: 'Programme deleted.', id: req.params.id });
});

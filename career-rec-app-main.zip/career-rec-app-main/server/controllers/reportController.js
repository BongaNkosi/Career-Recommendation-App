const { sequelize } = require('../config/db');
const { asyncHandler } = require('../middleware/errorHandler');
const { QueryTypes } = require('sequelize');

function toCSV(data) {
  if (!data?.length) return '';
  const headers = Object.keys(data[0]);
  const rows = data.map(r => headers.map(h => {
    const v = r[h];
    if (v === null || v === undefined) return '';
    const s = String(v);
    return s.includes(',') || s.includes('"') ? `"${s.replace(/"/g, '""')}"` : s;
  }).join(','));
  return [headers.join(','), ...rows].join('\n');
}

exports.getAdminStats = asyncHandler(async (req, res) => {
  const [stats] = await sequelize.query(`
    SELECT
      (SELECT COUNT(*) FROM users WHERE role='learner' AND is_active=1) AS learners,
      (SELECT COUNT(*) FROM institutions WHERE is_active=1)             AS institutions,
      (SELECT COUNT(*) FROM programmes   WHERE is_active=1)            AS programmes,
      (SELECT COUNT(*) FROM recommendations WHERE status='applied')    AS applications
  `, { type: QueryTypes.SELECT });
  res.json(stats);
});

exports.getSummary = asyncHandler(async (req, res) => {
  const [totals] = await sequelize.query(`
    SELECT
      (SELECT COUNT(*) FROM users WHERE role='learner' AND is_active=1) AS total_learners,
      (SELECT COUNT(*) FROM institutions WHERE is_active=1)             AS total_institutions,
      (SELECT COUNT(*) FROM programmes   WHERE is_active=1)             AS total_programmes,
      (SELECT COUNT(*) FROM recommendations)                            AS total_recommendations,
      (SELECT COUNT(*) FROM recommendations WHERE status='applied')     AS applied_count,
      (SELECT COUNT(*) FROM recommendations WHERE status='accepted')    AS accepted_count,
      (SELECT ROUND(AVG(mark),1) FROM learner_marks)                    AS avg_mark
  `, { type: QueryTypes.SELECT });

  const topProgrammes = await sequelize.query(`
    SELECT p.name AS programme, i.abbreviation AS institution,
           COUNT(r.recommendation_id) AS demand, p.aps_requirement, p.field
    FROM recommendations r
    JOIN programmes p ON r.programme_id = p.programme_id
    JOIN institutions i ON p.institution_id = i.institution_id
    GROUP BY r.programme_id ORDER BY demand DESC LIMIT 10
  `, { type: QueryTypes.SELECT });

  const byField = await sequelize.query(`
    SELECT p.field, COUNT(r.recommendation_id) AS count
    FROM recommendations r JOIN programmes p ON r.programme_id = p.programme_id
    GROUP BY p.field ORDER BY count DESC
  `, { type: QueryTypes.SELECT });

  const byProvince = await sequelize.query(`
    SELECT province, COUNT(*) AS learner_count
    FROM users WHERE role='learner' AND is_active=1
    GROUP BY province ORDER BY learner_count DESC
  `, { type: QueryTypes.SELECT });

  res.json({ totals, topProgrammes, byField, byProvince });
});

exports.getLearnerPerformance = asyncHandler(async (req, res) => {
  const { province, year = new Date().getFullYear() } = req.query;
  let sql = `
    SELECT u.user_id, u.first_name, u.last_name, u.email, u.province,
           ROUND(AVG(lm.mark), 1) AS average_mark,
           COUNT(lm.mark_id) AS subjects_entered, lm.academic_year
    FROM users u
    JOIN learner_marks lm ON u.user_id = lm.user_id
    WHERE u.role = 'learner' AND u.is_active = 1 AND lm.academic_year = :year
  `;
  const replacements = { year };
  if (province) { sql += ' AND u.province = :province'; replacements.province = province; }
  sql += ' GROUP BY u.user_id, lm.academic_year ORDER BY average_mark DESC';

  const rows = await sequelize.query(sql, { replacements, type: QueryTypes.SELECT });
  if (req.query.export === 'csv') {
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="learner_performance_${year}.csv"`);
    return res.send(toCSV(rows));
  }
  res.json(rows);
});

exports.getByInstitution = asyncHandler(async (req, res) => {
  const { province, field, status } = req.query;
  let sql = `
    SELECT i.name AS institution, i.abbreviation, i.province, i.type, p.field, p.name AS programme,
           COUNT(r.recommendation_id) AS recommendation_count,
           SUM(CASE WHEN r.status='applied' THEN 1 ELSE 0 END) AS applied,
           SUM(CASE WHEN r.status='accepted' THEN 1 ELSE 0 END) AS accepted,
           ROUND(AVG(r.match_percentage), 1) AS avg_match_pct
    FROM recommendations r
    JOIN programmes p ON r.programme_id = p.programme_id
    JOIN institutions i ON p.institution_id = i.institution_id WHERE 1=1
  `;
  const replacements = {};
  if (province) { sql += ' AND i.province = :province'; replacements.province = province; }
  if (field)    { sql += ' AND p.field = :field';       replacements.field    = field; }
  if (status)   { sql += ' AND r.status = :status';     replacements.status   = status; }
  sql += ' GROUP BY p.programme_id ORDER BY recommendation_count DESC';

  const rows = await sequelize.query(sql, { replacements, type: QueryTypes.SELECT });
  if (req.query.export === 'csv') {
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="recommendations_by_institution.csv"');
    return res.send(toCSV(rows));
  }
  res.json(rows);
});

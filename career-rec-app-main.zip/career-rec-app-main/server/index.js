require('dotenv').config();
const express = require('express');
const helmet  = require('helmet');
const cors    = require('cors');
const morgan  = require('morgan');

const { connectDB }   = require('./config/db');
const { errorHandler } = require('./middleware/errorHandler');
const { apiLimiter }   = require('./middleware/rateLimiter');

// ─── Validate required env vars ───────────────────────────────
const REQUIRED_ENV = ['JWT_SECRET', 'DB_HOST', 'DB_USER', 'DB_PASSWORD', 'DB_NAME'];
const missing = REQUIRED_ENV.filter(k => !process.env[k]);
if (missing.length) {
  console.error(`❌  Missing required environment variables: ${missing.join(', ')}`);
  console.error('    Copy .env.example to .env and fill in all values.');
  process.exit(1);
}

const app = express();

// ─── Security headers ─────────────────────────────────────────
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: false, // Adjust for your needs in production
}));

// ─── CORS ─────────────────────────────────────────────────────
const allowedOrigins = (process.env.CLIENT_URL || 'http://localhost:5173')
  .split(',')
  .map(o => o.trim());

app.use(cors({
  origin: (origin, cb) => {
    // Allow requests with no origin (mobile apps, curl, Postman)
    if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
    cb(new Error(`CORS: Origin ${origin} not allowed.`));
  },
  methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization'],
  credentials: true,
}));

// ─── Request logging ──────────────────────────────────────────
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// ─── Body parsing ─────────────────────────────────────────────
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true }));

// ─── General rate limiter ─────────────────────────────────────
app.use('/api', apiLimiter);

// ─── Routes ──────────────────────────────────────────────────
app.use('/api/auth',            require('./routes/auth'));
app.use('/api/institutions',    require('./routes/institutions'));
app.use('/api/programmes',      require('./routes/programmes'));
app.use('/api/learners',        require('./routes/learners'));
app.use('/api/marks',           require('./routes/marks'));
app.use('/api/recommendations', require('./routes/recommendations'));
app.use('/api/reports',         require('./routes/reports'));

// ─── Health check ─────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', env: process.env.NODE_ENV, time: new Date().toISOString() });
});

// ─── 404 for unknown API routes ──────────────────────────────
app.use('/api/*', (req, res) => {
  res.status(404).json({ message: `Route ${req.originalUrl} not found.` });
});

// ─── Global error handler (MUST BE LAST) ─────────────────────
app.use(errorHandler);

// ─── Start server ─────────────────────────────────────────────
const PORT = parseInt(process.env.PORT) || 5000;

const start = async () => {
  await connectDB();
  app.listen(PORT, '0.0.0.0', () => {
    console.log('');
    console.log('╔══════════════════════════════════════════════╗');
    console.log('║   🎓  CareerRec — API Server v2.0            ║');
    console.log(`║   Port    : ${String(PORT).padEnd(33)}║`);
    console.log(`║   Env     : ${(process.env.NODE_ENV||'development').padEnd(33)}║`);
    console.log(`║   CORS    : ${allowedOrigins[0].padEnd(33)}║`);
    console.log('╚══════════════════════════════════════════════╝');
    console.log('');
  });
};

start();

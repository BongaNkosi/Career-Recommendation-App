/**
 * Global error handler.
 * Must be registered LAST in Express middleware chain.
 */
const errorHandler = (err, req, res, next) => {
  const isDev = process.env.NODE_ENV !== 'production';

  // Sequelize validation errors
  if (err.name === 'SequelizeValidationError' || err.name === 'SequelizeUniqueConstraintError') {
    const messages = err.errors?.map(e => e.message) || [err.message];
    return res.status(400).json({ message: messages[0], errors: messages });
  }

  // JWT errors (shouldn't reach here if auth middleware handles them, but just in case)
  if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
    return res.status(401).json({ message: 'Authentication failed. Please sign in again.' });
  }

  const status  = err.status || err.statusCode || 500;
  const message = err.expose || status < 500
    ? err.message
    : 'An unexpected error occurred. Please try again.';

  console.error(`[${new Date().toISOString()}] ${req.method} ${req.path} — ${err.message}`);
  if (isDev && status === 500) console.error(err.stack);

  res.status(status).json({
    message,
    ...(isDev && status === 500 ? { stack: err.stack } : {}),
  });
};

/** Wrap async route handlers to forward errors to errorHandler. */
const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

/** Create an HTTP error with a status code. */
const createError = (status, message) => {
  const err = new Error(message);
  err.status = status;
  err.expose  = true;
  return err;
};

module.exports = { errorHandler, asyncHandler, createError };

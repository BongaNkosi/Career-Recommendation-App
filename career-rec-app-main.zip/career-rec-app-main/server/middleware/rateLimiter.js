const rateLimit = require('express-rate-limit');

/** Strict limiter for auth endpoints (prevent brute force). */
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20,
  message: { message: 'Too many attempts from this IP. Please wait 15 minutes and try again.' },
  standardHeaders: true,
  legacyHeaders: false,
});

/** General API rate limiter. */
const apiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 120,
  message: { message: 'Too many requests. Please slow down.' },
  standardHeaders: true,
  legacyHeaders: false,
});

module.exports = { authLimiter, apiLimiter };

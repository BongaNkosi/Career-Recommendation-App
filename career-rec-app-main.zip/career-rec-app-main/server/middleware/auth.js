const jwt = require('jsonwebtoken');

/**
 * Verify JWT from Authorization header.
 * Attaches decoded payload to req.user.
 */
const authenticate = (req, res, next) => {
  try {
    const header = req.headers['authorization'];
    if (!header?.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'Authentication required. Please sign in.' });
    }
    const token = header.split(' ')[1];
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ message: 'Your session has expired. Please sign in again.' });
    }
    return res.status(401).json({ message: 'Invalid token. Please sign in.' });
  }
};

/** Restrict to admin role only (use after authenticate). */
const requireAdmin = (req, res, next) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied. Admin privileges required.' });
  }
  next();
};

/** Restrict to learner role only (use after authenticate). */
const requireLearner = (req, res, next) => {
  if (req.user?.role !== 'learner') {
    return res.status(403).json({ message: 'Access denied. This area is for learners only.' });
  }
  next();
};

module.exports = { authenticate, requireAdmin, requireLearner };

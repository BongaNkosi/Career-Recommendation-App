const router = require('express').Router();
const ctrl   = require('../controllers/marksController');
const { authenticate, requireAdmin } = require('../middleware/auth');

router.get('/subjects',         ctrl.getSubjects);
router.get('/learner/:userId',  authenticate, requireAdmin, ctrl.getLearnerMarks);
router.get('/',                 authenticate, ctrl.getAll);
router.post('/',                authenticate, ctrl.create);
router.put('/:id',              authenticate, ctrl.update);
router.delete('/:id',           authenticate, ctrl.remove);

module.exports = router;

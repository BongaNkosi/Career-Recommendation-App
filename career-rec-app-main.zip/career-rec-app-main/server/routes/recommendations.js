const router = require('express').Router();
const ctrl   = require('../controllers/recommendationController');
const { authenticate } = require('../middleware/auth');

router.get('/',             authenticate, ctrl.getAll);
router.post('/generate',    authenticate, ctrl.generate);
router.patch('/:id/status', authenticate, ctrl.updateStatus);

module.exports = router;

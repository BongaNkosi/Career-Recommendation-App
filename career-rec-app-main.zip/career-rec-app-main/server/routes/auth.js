const router = require('express').Router();
const ctrl   = require('../controllers/authController');
const { authLimiter } = require('../middleware/rateLimiter');
const { authenticate } = require('../middleware/auth');

router.post('/register', authLimiter, ctrl.register);
router.post('/login',    authLimiter, ctrl.login);
router.get('/me',        authenticate, ctrl.getMe);

module.exports = router;

const router = require('express').Router();
const ctrl   = require('../controllers/learnerController');
const { authenticate, requireAdmin } = require('../middleware/auth');

router.get('/profile',  authenticate, ctrl.getProfile);
router.get('/',         authenticate, requireAdmin, ctrl.getAll);
router.get('/:id',      authenticate, requireAdmin, ctrl.getOne);
router.post('/',        authenticate, requireAdmin, ctrl.create);
router.put('/:id',      authenticate, requireAdmin, ctrl.update);
router.delete('/:id',   authenticate, requireAdmin, ctrl.remove);

module.exports = router;

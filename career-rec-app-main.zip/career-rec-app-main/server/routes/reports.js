const router = require('express').Router();
const ctrl   = require('../controllers/reportController');
const { authenticate, requireAdmin } = require('../middleware/auth');

router.get('/admin-stats',         authenticate, requireAdmin, ctrl.getAdminStats);
router.get('/summary',             authenticate, requireAdmin, ctrl.getSummary);
router.get('/learner-performance', authenticate, requireAdmin, ctrl.getLearnerPerformance);
router.get('/by-institution',      authenticate, requireAdmin, ctrl.getByInstitution);

module.exports = router;

const { Sequelize } = require('sequelize');
require('dotenv').config();

const sequelize = new Sequelize(
  process.env.DB_NAME     || 'career_rec_db',
  process.env.DB_USER     || 'career_user',
  process.env.DB_PASSWORD || '',
  {
    host:    process.env.DB_HOST || 'localhost',
    port:    parseInt(process.env.DB_PORT) || 3306,
    dialect: 'mysql',
    timezone: '+02:00',
    logging: process.env.NODE_ENV === 'development' ? (msg) => console.log(`[SQL] ${msg}`) : false,
    pool: {
      max: 10,
      min: 0,
      acquire: 30000,
      idle: 10000,
    },
    define: {
      underscored: true,
      timestamps: true,
    },
  }
);

const connectDB = async () => {
  try {
    await sequelize.authenticate();
    console.log('✅  MySQL connected →', process.env.DB_HOST || 'localhost');

    const syncMode = process.env.DB_SYNC;
    if (syncMode === 'force') {
      await sequelize.sync({ force: true });
      console.log('⚠️   DB synced (FORCE — all tables dropped and recreated)');
    } else if (syncMode === 'alter') {
      await sequelize.sync({ alter: true });
      console.log('🔄  DB synced (ALTER)');
    }
  } catch (err) {
    console.error('❌  MySQL connection failed:', err.message);
    process.exit(1);
  }
};

module.exports = { sequelize, connectDB };

/**
 * DB Sync script — run once to create/update all tables.
 * Usage: node scripts/syncDb.js
 * 
 * Set DB_SYNC in .env to control sync mode:
 *   alter  → safe: adds/modifies columns (recommended for dev)
 *   force  → destructive: drops and recreates all tables
 *   (anything else) → no sync, just test the connection
 */
require('dotenv').config({ path: require('path').join(__dirname, '../.env') });
const { connectDB, sequelize } = require('../config/db');

// Import all models so Sequelize registers them before sync
require('../models');

async function syncDb() {
  try {
    await connectDB();
    console.log('\n✅  Connection verified.');
    console.log(`🔄  DB_SYNC mode: "${process.env.DB_SYNC || 'none'}"`);
    console.log('📦  Tables synced successfully.\n');
    process.exit(0);
  } catch (err) {
    console.error('❌  Sync failed:', err.message);
    process.exit(1);
  }
}

syncDb();
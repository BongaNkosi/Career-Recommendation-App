/**
 * Seed script — run once after setting up the database.
 * Creates admin user, sample institutions, programmes, and subjects.
 * Usage: node scripts/seed.js
 */
require('dotenv').config({ path: require('path').join(__dirname, '../.env') });
const bcrypt = require('bcryptjs');
const { connectDB } = require('../config/db');
const { User, Institution, Programme, Subject } = require('../models');

async function seed() {
  await connectDB();
  console.log('\n🌱  Seeding database...\n');

  // ─── Admin user ────────────────────────────────────────────
  const [admin] = await User.findOrCreate({
    where: { email: 'admin@careerrec.ac.za' },
    defaults: {
      first_name: 'System',
      last_name: 'Administrator',
      email: 'admin@careerrec.ac.za',
      password_hash: await bcrypt.hash('Admin@CareerRec1', 12),
      role: 'admin',
      province: 'Gauteng',
    },
  });
  console.log(`✅  Admin:  ${admin.email}`);

  // ─── Subjects ──────────────────────────────────────────────
  // All 11 official SA languages offered as Home Language (HL)
  // Most learners take one HL + English FAL (or another FAL)
  const subjectData = [
    // ── Home Languages (all 11 official SA languages) ──────────
    { name: 'English Home Language',            code: 'EHL',    subject_type: 'compulsory' },
    { name: 'Afrikaans Home Language',           code: 'AHL',    subject_type: 'compulsory' },
    { name: 'IsiZulu Home Language',             code: 'ZUHL',   subject_type: 'compulsory' },
    { name: 'IsiXhosa Home Language',            code: 'XHHL',   subject_type: 'compulsory' },
    { name: 'Sesotho Home Language',             code: 'SSHL',   subject_type: 'compulsory' },
    { name: 'Setswana Home Language',            code: 'TNHL',   subject_type: 'compulsory' },
    { name: 'Sepedi Home Language',              code: 'SPHL',   subject_type: 'compulsory' },
    { name: 'Xitsonga Home Language',            code: 'TSHL',   subject_type: 'compulsory' },
    { name: 'SiSwati Home Language',             code: 'SWHL',   subject_type: 'compulsory' },
    { name: 'Tshivenda Home Language',           code: 'VEHL',   subject_type: 'compulsory' },
    { name: 'IsiNdebele Home Language',          code: 'NDHL',   subject_type: 'compulsory' },

    // ── First Additional Languages ──────────────────────────────
    // English FAL is by far the most common choice
    { name: 'English First Additional Language',    code: 'EFAL',  subject_type: 'compulsory' },
    { name: 'Afrikaans First Additional Language',  code: 'AFAL',  subject_type: 'compulsory' },
    { name: 'IsiZulu First Additional Language',    code: 'ZUFAL', subject_type: 'compulsory' },
    { name: 'IsiXhosa First Additional Language',   code: 'XHFAL', subject_type: 'compulsory' },
    { name: 'Sesotho First Additional Language',    code: 'SSFAL', subject_type: 'compulsory' },
    { name: 'Setswana First Additional Language',   code: 'TNFAL', subject_type: 'compulsory' },
    { name: 'Sepedi First Additional Language',     code: 'SPFAL', subject_type: 'compulsory' },
    { name: 'Xitsonga First Additional Language',   code: 'TSFAL', subject_type: 'compulsory' },
    { name: 'SiSwati First Additional Language',    code: 'SWFAL', subject_type: 'compulsory' },
    { name: 'Tshivenda First Additional Language',  code: 'VEFAL', subject_type: 'compulsory' },
    { name: 'IsiNdebele First Additional Language', code: 'NDFAL', subject_type: 'compulsory' },

    // ── Compulsory non-language ─────────────────────────────────
    { name: 'Life Orientation', code: 'LO', subject_type: 'compulsory' },

    // ── Electives ───────────────────────────────────────────────
    { name: 'Mathematics',                      code: 'MATH', subject_type: 'elective' },
    { name: 'Mathematical Literacy',            code: 'ML',   subject_type: 'elective' },
    { name: 'Technical Mathematics',            code: 'TM',   subject_type: 'elective' },
    { name: 'Physical Sciences',                code: 'PS',   subject_type: 'elective' },
    { name: 'Technical Sciences',               code: 'TS',   subject_type: 'elective' },
    { name: 'Life Sciences',                    code: 'LS',   subject_type: 'elective' },
    { name: 'Geography',                        code: 'GEO',  subject_type: 'elective' },
    { name: 'History',                          code: 'HIS',  subject_type: 'elective' },
    { name: 'Accounting',                       code: 'ACC',  subject_type: 'elective' },
    { name: 'Business Studies',                 code: 'BS',   subject_type: 'elective' },
    { name: 'Economics',                        code: 'ECO',  subject_type: 'elective' },
    { name: 'Computer Applications Technology', code: 'CAT',  subject_type: 'elective' },
    { name: 'Information Technology',           code: 'IT',   subject_type: 'elective' },
    { name: 'Visual Arts',                      code: 'VA',   subject_type: 'elective' },
    { name: 'Dramatic Arts',                    code: 'DA',   subject_type: 'elective' },
    { name: 'Music',                            code: 'MUS',  subject_type: 'elective' },
    { name: 'Dance Studies',                    code: 'DAN',  subject_type: 'elective' },
    { name: 'Tourism',                          code: 'TOU',  subject_type: 'elective' },
    { name: 'Agricultural Sciences',            code: 'AGS',  subject_type: 'elective' },
    { name: 'Agricultural Management Practices',code: 'AMP',  subject_type: 'elective' },
    { name: 'Consumer Studies',                 code: 'CS',   subject_type: 'elective' },
    { name: 'Hospitality Studies',              code: 'HS',   subject_type: 'elective' },
    { name: 'Engineering Graphics & Design',    code: 'EGD',  subject_type: 'elective' },
    { name: 'Civil Technology',                 code: 'CVT',  subject_type: 'elective' },
    { name: 'Electrical Technology',            code: 'ELT',  subject_type: 'elective' },
    { name: 'Mechanical Technology',            code: 'MCT',  subject_type: 'elective' },
    { name: 'Religion Studies',                 code: 'RS',   subject_type: 'elective' },
    { name: 'Sport and Exercise Science',       code: 'SES',  subject_type: 'elective' },
  ];
  for (const s of subjectData) await Subject.findOrCreate({ where: { code: s.code }, defaults: s });
  console.log(`✅  Subjects: ${subjectData.length} seeded`);

  // ─── Institutions ──────────────────────────────────────────
  const institutions = [
    { name: 'University of Pretoria', abbreviation: 'UP', type: 'University', province: 'Gauteng', city: 'Pretoria', website: 'https://www.up.ac.za' },
    { name: 'University of the Witwatersrand', abbreviation: 'WITS', type: 'University', province: 'Gauteng', city: 'Johannesburg', website: 'https://www.wits.ac.za' },
    { name: 'Tshwane University of Technology', abbreviation: 'TUT', type: 'University of Technology', province: 'Gauteng', city: 'Pretoria', website: 'https://www.tut.ac.za' },
    { name: 'University of Cape Town', abbreviation: 'UCT', type: 'University', province: 'Western Cape', city: 'Cape Town', website: 'https://www.uct.ac.za' },
    { name: 'Stellenbosch University', abbreviation: 'SU', type: 'University', province: 'Western Cape', city: 'Stellenbosch', website: 'https://www.sun.ac.za' },
    { name: 'University of KwaZulu-Natal', abbreviation: 'UKZN', type: 'University', province: 'KwaZulu-Natal', city: 'Durban', website: 'https://www.ukzn.ac.za' },
  ];
  const savedInstitutions = {};
  for (const inst of institutions) {
    const [record] = await Institution.findOrCreate({ where: { abbreviation: inst.abbreviation }, defaults: inst });
    savedInstitutions[inst.abbreviation] = record.institution_id;
  }
  console.log(`✅  Institutions: ${institutions.length} seeded`);

  // ─── Programmes ────────────────────────────────────────────
  const programmes = [
    { institution: 'UP', name: 'BSc Computer Science', faculty: 'Engineering, Built Environment and IT', field: 'Information Technology', aps_requirement: 32, duration_years: 3 },
    { institution: 'UP', name: 'BEng Civil Engineering', faculty: 'Engineering', field: 'Engineering & Technology', aps_requirement: 34, duration_years: 4 },
    { institution: 'UP', name: 'MBChB Medicine', faculty: 'Health Sciences', field: 'Health Sciences', aps_requirement: 40, duration_years: 6 },
    { institution: 'UP', name: 'BCom Accounting', faculty: 'Economic and Management Sciences', field: 'Business & Management', aps_requirement: 30, duration_years: 3 },
    { institution: 'WITS', name: 'BSc Engineering (Electrical)', faculty: 'Engineering', field: 'Engineering & Technology', aps_requirement: 36, duration_years: 4 },
    { institution: 'WITS', name: 'BA Law', faculty: 'Law', field: 'Law', aps_requirement: 33, duration_years: 3 },
    { institution: 'WITS', name: 'BDS Dentistry', faculty: 'Health Sciences', field: 'Health Sciences', aps_requirement: 38, duration_years: 5 },
    { institution: 'TUT', name: 'BTech Information Technology', faculty: 'ICT', field: 'Information Technology', aps_requirement: 22, duration_years: 4 },
    { institution: 'TUT', name: 'National Diploma Engineering (Electrical)', faculty: 'Engineering', field: 'Engineering & Technology', aps_requirement: 20, duration_years: 3 },
    { institution: 'TUT', name: 'BTech Accounting', faculty: 'Management Sciences', field: 'Business & Management', aps_requirement: 20, duration_years: 4 },
    { institution: 'UCT', name: 'BSc Computer Science', faculty: 'Science', field: 'Information Technology', aps_requirement: 38, duration_years: 3 },
    { institution: 'UCT', name: 'MBChB Medicine', faculty: 'Health Sciences', field: 'Health Sciences', aps_requirement: 42, duration_years: 6 },
    { institution: 'SU', name: 'BEng Mechanical Engineering', faculty: 'Engineering', field: 'Engineering & Technology', aps_requirement: 36, duration_years: 4 },
    { institution: 'SU', name: 'BA Psychology', faculty: 'Arts and Social Sciences', field: 'Humanities & Social Sciences', aps_requirement: 30, duration_years: 3 },
    { institution: 'UKZN', name: 'BSc Agricultural Sciences', faculty: 'Science and Agriculture', field: 'Agriculture', aps_requirement: 26, duration_years: 3 },
    { institution: 'UKZN', name: 'BEduc Education', faculty: 'Education', field: 'Education', aps_requirement: 24, duration_years: 4 },
  ];

  let progCount = 0;
  for (const p of programmes) {
    const institutionId = savedInstitutions[p.institution];
    if (!institutionId) continue;
    await Programme.findOrCreate({
      where: { name: p.name, institution_id: institutionId },
      defaults: { faculty: p.faculty, field: p.field, aps_requirement: p.aps_requirement, duration_years: p.duration_years, institution_id: institutionId, nqf_level: 7 },
    });
    progCount++;
  }
  console.log(`✅  Programmes: ${progCount} seeded`);

  console.log('\n🎉  Seeding complete!\n');
  console.log('   Admin credentials:');
  console.log('   Email   : admin@careerrec.ac.za');
  console.log('   Password: Admin@CareerRec1');
  console.log('   ⚠️   Change this password immediately after first login.\n');
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');

// ─── User ───────────────────────────────────────────────────────────────────
const User = sequelize.define('User', {
  user_id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  first_name: { type: DataTypes.STRING(80), allowNull: false },
  last_name:  { type: DataTypes.STRING(80), allowNull: false },
  email:      { type: DataTypes.STRING(255), allowNull: false, unique: true,
    validate: { isEmail: true },
    set(val) { this.setDataValue('email', val?.toLowerCase().trim()); },
  },
  password_hash: { type: DataTypes.STRING(255), allowNull: false },
  role: { type: DataTypes.ENUM('learner','admin'), allowNull: false, defaultValue: 'learner' },
  province: { type: DataTypes.STRING(60), allowNull: true },
  gender: { type: DataTypes.ENUM('male','female','other','prefer_not_to_say'), allowNull: true },
  date_of_birth: { type: DataTypes.DATEONLY, allowNull: true },
  profile_image: { type: DataTypes.STRING(500), allowNull: true },
  is_active: { type: DataTypes.BOOLEAN, defaultValue: true },
}, {
  tableName: 'users',
  defaultScope: { attributes: { exclude: ['password_hash'] } },
  scopes: { withPassword: { attributes: {} } },
});

// ─── Institution ────────────────────────────────────────────────────────────
const Institution = sequelize.define('Institution', {
  institution_id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  name:         { type: DataTypes.STRING(200), allowNull: false },
  abbreviation: { type: DataTypes.STRING(20), allowNull: false,
    set(val) { this.setDataValue('abbreviation', val?.toUpperCase().trim()); },
  },
  type: { type: DataTypes.ENUM('University','University of Technology','TVET College','Private'), allowNull: false },
  province: { type: DataTypes.STRING(60), allowNull: false },
  city:     { type: DataTypes.STRING(80), allowNull: false },
  website:  { type: DataTypes.STRING(300), allowNull: true },
  logo_url: { type: DataTypes.STRING(500), allowNull: true },
  description: { type: DataTypes.TEXT, allowNull: true },
  is_active: { type: DataTypes.BOOLEAN, defaultValue: true },
}, { tableName: 'institutions' });

// ─── Programme ──────────────────────────────────────────────────────────────
const Programme = sequelize.define('Programme', {
  programme_id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  institution_id: { type: DataTypes.INTEGER, allowNull: false },
  name:    { type: DataTypes.STRING(200), allowNull: false },
  faculty: { type: DataTypes.STRING(150), allowNull: true },
  field: {
    type: DataTypes.ENUM(
      'Engineering & Technology','Health Sciences','Business & Management',
      'Natural Sciences','Humanities & Social Sciences','Law',
      'Education','Agriculture','Arts & Design','Information Technology'
    ), allowNull: false,
  },
  aps_requirement:  { type: DataTypes.INTEGER, allowNull: false, validate: { min: 1, max: 42 } },
  duration_years:   { type: DataTypes.INTEGER, allowNull: false, defaultValue: 3 },
  nqf_level:        { type: DataTypes.INTEGER, allowNull: true, defaultValue: 7 },
  description:      { type: DataTypes.TEXT, allowNull: true },
  is_active:        { type: DataTypes.BOOLEAN, defaultValue: true },
}, { tableName: 'programmes' });

// ─── Subject ─────────────────────────────────────────────────────────────────
const Subject = sequelize.define('Subject', {
  subject_id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  name: { type: DataTypes.STRING(100), allowNull: false },
  code: { type: DataTypes.STRING(20), allowNull: true },
  subject_type: { type: DataTypes.ENUM('compulsory','elective'), defaultValue: 'elective' },
}, { tableName: 'subjects', timestamps: false });

// ─── LearnerMark ─────────────────────────────────────────────────────────────
const LearnerMark = sequelize.define('LearnerMark', {
  mark_id:      { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  user_id:      { type: DataTypes.INTEGER, allowNull: false },
  subject_id:   { type: DataTypes.INTEGER, allowNull: false },
  mark:         { type: DataTypes.DECIMAL(5,2), allowNull: false, validate: { min: 0, max: 100 } },
  grade:        { type: DataTypes.INTEGER, defaultValue: 12 },
  academic_year:{ type: DataTypes.INTEGER, allowNull: false },
}, {
  tableName: 'learner_marks',
  indexes: [{ unique: true, fields: ['user_id', 'subject_id', 'academic_year'] }],
});

// ─── Recommendation ──────────────────────────────────────────────────────────
const Recommendation = sequelize.define('Recommendation', {
  recommendation_id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  user_id:       { type: DataTypes.INTEGER, allowNull: false },
  programme_id:  { type: DataTypes.INTEGER, allowNull: false },
  aps_score:     { type: DataTypes.INTEGER, allowNull: false },
  match_percentage: { type: DataTypes.DECIMAL(5,2), allowNull: true },
  status: {
    type: DataTypes.ENUM('generated','viewed','applied','accepted','rejected'),
    defaultValue: 'generated',
  },
  academic_year: { type: DataTypes.INTEGER, allowNull: false },
}, { tableName: 'recommendations' });

// ─── Associations ─────────────────────────────────────────────────────────────
Institution.hasMany(Programme,  { foreignKey: 'institution_id', as: 'programmes' });
Programme.belongsTo(Institution,{ foreignKey: 'institution_id', as: 'institution' });

User.hasMany(LearnerMark,     { foreignKey: 'user_id', as: 'marks' });
LearnerMark.belongsTo(User,   { foreignKey: 'user_id', as: 'user' });
Subject.hasMany(LearnerMark,  { foreignKey: 'subject_id', as: 'marks' });
LearnerMark.belongsTo(Subject,{ foreignKey: 'subject_id', as: 'subject' });

User.hasMany(Recommendation,        { foreignKey: 'user_id',      as: 'recommendations' });
Recommendation.belongsTo(User,      { foreignKey: 'user_id',      as: 'user' });
Programme.hasMany(Recommendation,   { foreignKey: 'programme_id', as: 'recommendations' });
Recommendation.belongsTo(Programme, { foreignKey: 'programme_id', as: 'programme' });

module.exports = { User, Institution, Programme, Subject, LearnerMark, Recommendation };

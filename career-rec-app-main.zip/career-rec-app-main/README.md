# 🎓 CareerRec — Production-Ready Career Recommendation App

A full-stack web application that helps South African matric learners discover university programmes matched to their APS score.

## Tech Stack

| Layer      | Technology                                        |
|------------|---------------------------------------------------|
| Frontend   | React 18 + Vite + Tailwind CSS + lucide-react     |
| Backend    | Node.js + Express.js                              |
| Database   | MySQL 8+                                          |
| ORM        | Sequelize v6                                      |
| Auth       | JWT (jsonwebtoken) + bcryptjs                     |
| Security   | helmet, express-rate-limit, CORS whitelist        |
| Logging    | morgan                                            |

---

## Prerequisites

- Node.js ≥ 18
- MySQL 8.0+
- npm ≥ 9

---

## Quick Start

### 1. Clone & install dependencies

```bash
git clone https://github.com/dennis-mmachoene/career-rec-app.git
cd career-rec-app

npm install          # install root concurrently
npm run install:all  # install server + client deps
```

### 2. Set up environment variables

```bash
cp server/.env.example server/.env
```

Edit `server/.env` with your values:

```env
PORT=5000
NODE_ENV=development
CLIENT_URL=http://localhost:5173

JWT_SECRET=your_long_random_secret_at_least_64_characters
JWT_EXPIRES_IN=8h

DB_HOST=localhost
DB_PORT=3306
DB_USER=career_user
DB_PASSWORD=your_password
DB_NAME=career_rec_db

DB_SYNC=alter
```

> ⚠️ **Generate a strong JWT secret:**  
> `node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"`

---

### 3. Set up MySQL

```sql
-- Run in MySQL as root:
CREATE DATABASE career_rec_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'career_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON career_rec_db.* TO 'career_user'@'localhost';
FLUSH PRIVILEGES;
```

### 4. Seed the database

```bash
npm run db:seed
```

This creates:
- ✅ Admin account: `admin@careerrec.ac.za` / `Admin@CareerRec1`
- ✅ 18 NSC subjects
- ✅ 6 major South African institutions (UP, WITS, TUT, UCT, SU, UKZN)
- ✅ 16 sample programmes

> ⚠️ Change the admin password immediately after first login!

### 5. Run in development mode

```bash
npm run dev
```

This starts both the Express API (port 5000) and Vite dev server (port 5173) concurrently.

Open: **http://localhost:5173**

---

## Project Structure

```
career-rec-app/
├── server/
│   ├── config/
│   │   └── db.js              # Sequelize + MySQL connection
│   ├── controllers/
│   │   ├── authController.js  # Register (auto-auth) + Login + Me
│   │   ├── institutionController.js
│   │   ├── programmeController.js
│   │   ├── marksController.js # APS calculation in JS
│   │   ├── recommendationController.js
│   │   ├── learnerController.js
│   │   └── reportController.js
│   ├── middleware/
│   │   ├── auth.js            # JWT authenticate, requireAdmin, requireLearner
│   │   ├── errorHandler.js    # Global error handler + asyncHandler
│   │   └── rateLimiter.js     # Auth (20/15min) + API (120/min) limiters
│   ├── models/
│   │   └── index.js           # All Sequelize models + associations
│   ├── routes/
│   │   ├── auth.js
│   │   ├── institutions.js
│   │   ├── programmes.js
│   │   ├── learners.js
│   │   ├── marks.js
│   │   ├── recommendations.js
│   │   └── reports.js
│   ├── scripts/
│   │   └── seed.js
│   ├── .env.example
│   ├── index.js               # Express entry point
│   └── package.json
│
├── client/
│   ├── src/
│   │   ├── api/index.js           # Axios instance + interceptors
│   │   ├── components/
│   │   │   ├── layout/
│   │   │   │   ├── AppShell.jsx   # Main layout with sidebar
│   │   │   │   └── Sidebar.jsx    # Navigation sidebar
│   │   │   ├── ui/
│   │   │   │   ├── Modal.jsx
│   │   │   │   └── Toast.jsx
│   │   │   └── ProtectedRoute.jsx
│   │   ├── context/
│   │   │   └── AuthContext.jsx    # Auth state, login, register, logout
│   │   ├── hooks/
│   │   │   └── useToast.js
│   │   ├── pages/
│   │   │   ├── auth/
│   │   │   │   ├── Login.jsx      # No demo credentials
│   │   │   │   └── Register.jsx   # Auto-authenticates after signup
│   │   │   ├── admin/
│   │   │   │   ├── Dashboard.jsx
│   │   │   │   ├── Institutions.jsx
│   │   │   │   ├── Programmes.jsx
│   │   │   │   ├── Learners.jsx
│   │   │   │   ├── Marks.jsx
│   │   │   │   └── Reports.jsx
│   │   │   └── learner/
│   │   │       ├── Dashboard.jsx
│   │   │       ├── EnterMarks.jsx
│   │   │       ├── Recommendations.jsx
│   │   │       └── ViewProgrammes.jsx
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── index.css
│   ├── index.html
│   ├── vite.config.js
│   ├── tailwind.config.js
│   └── package.json
│
├── package.json    # Root with concurrently scripts
└── README.md
```

---

## Authentication Flow

### Sign Up → Auto-Login
1. User fills in registration form
2. `POST /api/auth/register` creates account, hashes password, returns `{ token, user }`
3. Frontend stores JWT in `localStorage`, sets auth state
4. User is **immediately redirected to `/learner` dashboard** — no login page redirect

### Login
1. `POST /api/auth/login` validates credentials, returns `{ token, user }`
2. Frontend stores JWT, redirects to role-appropriate dashboard

### Protected Routes
- All protected API routes check `Authorization: Bearer <token>` header
- `authenticate` middleware verifies JWT and attaches `req.user`
- `requireAdmin` restricts admin-only routes
- Frontend `ProtectedRoute` component guards UI routes by role

---

## Security Features

| Feature              | Implementation                              |
|----------------------|---------------------------------------------|
| Password hashing     | bcryptjs, cost factor 12                    |
| JWT auth             | HS256, configurable expiry                  |
| Security headers     | helmet                                      |
| CORS                 | Whitelist via `CLIENT_URL` env var          |
| Rate limiting        | 20 req/15min (auth), 120 req/min (API)      |
| Input validation     | Server-side in controllers                  |
| SQL injection        | Sequelize parameterised queries             |
| Error exposure       | Stack traces hidden in production           |
| Secrets              | All via `.env`, never hardcoded             |

---

## APS Calculation

APS (Admission Point Score) is calculated in `server/controllers/marksController.js`:

| Mark Range | APS Points |
|-----------|-----------|
| 80–100%   | 7         |
| 70–79%    | 6         |
| 60–69%    | 5         |
| 50–59%    | 4         |
| 40–49%    | 3         |
| 30-39%    | 2         |
| 0–29%     | 1         |

Top 6 subjects are used (excluding Life Orientation).

---

## Available Scripts

| Command              | Description                                      |
|----------------------|--------------------------------------------------|
| `npm run dev`        | Start both server and client in watch mode       |
| `npm run dev:server` | Start only Express server                        |
| `npm run dev:client` | Start only Vite client                           |
| `npm run db:seed`    | Seed database with sample data                   |
| `npm run build:client` | Build React app for production                 |

---

## API Endpoints

### Auth
| Method | Path                 | Auth     | Description          |
|--------|----------------------|----------|----------------------|
| POST   | /api/auth/register   | Public   | Register + auto-login|
| POST   | /api/auth/login      | Public   | Login                |
| GET    | /api/auth/me         | Required | Current user         |

### Institutions, Programmes, Marks, Recommendations, Reports
All follow RESTful conventions. See `server/routes/` for full details.

---

## Production Deployment

1. Set `NODE_ENV=production` in `.env`
2. Set `DB_SYNC=false` (use migrations in production)
3. Set `CLIENT_URL` to your production frontend domain
4. Build the client: `npm run build:client`
5. Use a process manager like PM2: `pm2 start server/index.js`

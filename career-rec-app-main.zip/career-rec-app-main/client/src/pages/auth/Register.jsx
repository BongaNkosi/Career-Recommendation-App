import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { User, Mail, Lock, MapPin, ArrowRight, GraduationCap, Eye, EyeOff, CheckCircle } from 'lucide-react';

const PROVINCES = [
  'Eastern Cape','Free State','Gauteng','KwaZulu-Natal',
  'Limpopo','Mpumalanga','Northern Cape','North West','Western Cape',
];

const PasswordStrength = ({ password }) => {
  const checks = [
    { label: '8+ characters', ok: password.length >= 8 },
    { label: 'Uppercase letter', ok: /[A-Z]/.test(password) },
    { label: 'Number', ok: /\d/.test(password) },
  ];
  if (!password) return null;
  return (
    <div className="mt-2 flex gap-3 flex-wrap">
      {checks.map(c => (
        <span key={c.label} className={`text-xs flex items-center gap-1 ${c.ok ? 'text-emerald-600' : 'text-slate-400'}`}>
          <CheckCircle className={`w-3 h-3 ${c.ok ? 'text-emerald-500' : 'text-slate-300'}`} />
          {c.label}
        </span>
      ))}
    </div>
  );
};

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    firstName: '', lastName: '', email: '', password: '', confirmPassword: '',
    province: '', gender: '', dateOfBirth: '', agreeTerms: false,
  });
  const [errors, setErrors]   = useState({});
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  const set = (k, v) => {
    setForm(f => ({ ...f, [k]: v }));
    setErrors(e => ({ ...e, [k]: '' }));
  };

  const validate = () => {
    const e = {};
    if (!form.firstName.trim()) e.firstName = 'Required.';
    if (!form.lastName.trim())  e.lastName  = 'Required.';
    if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Enter a valid email.';
    if (form.password.length < 8) e.password = 'Minimum 8 characters.';
    if (form.password !== form.confirmPassword) e.confirmPassword = 'Passwords do not match.';
    if (!form.province) e.province = 'Please select your province.';
    if (!form.gender)   e.gender   = 'Please select your gender.';
    if (!form.agreeTerms) e.agreeTerms = 'You must agree to the terms.';
    return e;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setLoading(true);
    try {
      // register() stores token & user automatically — no redirect to login needed
      await register({
        firstName: form.firstName.trim(),
        lastName:  form.lastName.trim(),
        email:     form.email.trim(),
        password:  form.password,
        province:  form.province,
        gender:    form.gender,
        dateOfBirth: form.dateOfBirth || null,
      });
      // Redirect straight into the app
      navigate('/learner', { replace: true });
    } catch (err) {
      setErrors({ submit: err.response?.data?.message || 'Registration failed. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-10 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6 group">
            <div className="w-10 h-10 bg-brand-600 rounded-xl flex items-center justify-center group-hover:bg-brand-700 transition-colors">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <span className="font-display font-bold text-2xl text-slate-900">CareerRec</span>
          </Link>
          <h1 className="font-display text-3xl font-bold text-slate-900 mb-2">Create your account</h1>
          <p className="text-slate-500">Join CareerRec and discover programmes matched to your APS score</p>
        </div>

        <div className="bg-white rounded-2xl shadow-card border border-slate-100 p-8 animate-slide-up">
          {errors.submit && (
            <div className="alert-error mb-6"><span>{errors.submit}</span></div>
          )}

          <form onSubmit={handleSubmit} noValidate>
            {/* Name row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
              <div>
                <label className="form-label">First Name <span className="text-red-400">*</span></label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input type="text" autoComplete="given-name"
                    className={`form-input pl-10 ${errors.firstName ? 'error' : ''}`}
                    placeholder="Thabo" value={form.firstName}
                    onChange={e => set('firstName', e.target.value)} />
                </div>
                {errors.firstName && <p className="form-error">{errors.firstName}</p>}
              </div>
              <div>
                <label className="form-label">Last Name <span className="text-red-400">*</span></label>
                <input type="text" autoComplete="family-name"
                  className={`form-input ${errors.lastName ? 'error' : ''}`}
                  placeholder="Mokoena" value={form.lastName}
                  onChange={e => set('lastName', e.target.value)} />
                {errors.lastName && <p className="form-error">{errors.lastName}</p>}
              </div>
            </div>

            {/* Email */}
            <div className="mb-5">
              <label className="form-label">Email Address <span className="text-red-400">*</span></label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input type="email" autoComplete="email"
                  className={`form-input pl-10 ${errors.email ? 'error' : ''}`}
                  placeholder="you@example.com" value={form.email}
                  onChange={e => set('email', e.target.value)} />
              </div>
              {errors.email && <p className="form-error">{errors.email}</p>}
            </div>

            {/* Password row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
              <div>
                <label className="form-label">Password <span className="text-red-400">*</span></label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input type={showPass ? 'text' : 'password'} autoComplete="new-password"
                    className={`form-input pl-10 pr-10 ${errors.password ? 'error' : ''}`}
                    placeholder="Min. 8 characters" value={form.password}
                    onChange={e => set('password', e.target.value)} />
                  <button type="button"
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    onClick={() => setShowPass(s => !s)}>
                    {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <PasswordStrength password={form.password} />
                {errors.password && <p className="form-error">{errors.password}</p>}
              </div>
              <div>
                <label className="form-label">Confirm Password <span className="text-red-400">*</span></label>
                <input type={showPass ? 'text' : 'password'} autoComplete="new-password"
                  className={`form-input ${errors.confirmPassword ? 'error' : ''}`}
                  placeholder="Repeat password" value={form.confirmPassword}
                  onChange={e => set('confirmPassword', e.target.value)} />
                {errors.confirmPassword && <p className="form-error">{errors.confirmPassword}</p>}
              </div>
            </div>

            {/* Province + DOB */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
              <div>
                <label className="form-label">Province <span className="text-red-400">*</span></label>
                <div className="relative">
                  <MapPin className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <select className={`form-input pl-10 ${errors.province ? 'error' : ''}`}
                    value={form.province} onChange={e => set('province', e.target.value)}>
                    <option value="">— Select Province —</option>
                    {PROVINCES.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
                {errors.province && <p className="form-error">{errors.province}</p>}
              </div>
              <div>
                <label className="form-label">Date of Birth <span className="text-slate-400 font-normal">(optional)</span></label>
                <input type="date" className="form-input" value={form.dateOfBirth}
                  max={new Date().toISOString().split('T')[0]}
                  onChange={e => set('dateOfBirth', e.target.value)} />
              </div>
            </div>

            {/* Gender */}
            <div className="mb-6">
              <label className="form-label">Gender <span className="text-red-400">*</span></label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[['male','Male'],['female','Female'],['other','Other'],['prefer_not_to_say','Prefer not to say']].map(([val, lbl]) => (
                  <label key={val}
                    className={`flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl border text-sm cursor-pointer transition-all
                      ${form.gender === val
                        ? 'border-brand-500 bg-brand-50 text-brand-700 font-medium'
                        : 'border-slate-200 text-slate-600 hover:border-slate-300'
                      }`}
                  >
                    <input type="radio" name="gender" value={val} checked={form.gender === val}
                      onChange={() => set('gender', val)} className="sr-only" />
                    {lbl}
                  </label>
                ))}
              </div>
              {errors.gender && <p className="form-error mt-1">{errors.gender}</p>}
            </div>

            {/* Terms */}
            <div className="mb-6">
              <label className={`flex items-start gap-3 cursor-pointer`}>
                <input type="checkbox" checked={form.agreeTerms}
                  onChange={e => set('agreeTerms', e.target.checked)}
                  className="mt-0.5 w-4 h-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500" />
                <span className="text-sm text-slate-600">
                  I agree to the{' '}
                  <a href="https://www.dhet.gov.za" target="_blank" rel="noreferrer" className="text-brand-600 hover:underline">Terms of Service</a>
                  {' '}and acknowledge the{' '}
                  <a href="https://popia.co.za" target="_blank" rel="noreferrer" className="text-brand-600 hover:underline">POPIA privacy policy</a>.
                </span>
              </label>
              {errors.agreeTerms && <p className="form-error mt-1">{errors.agreeTerms}</p>}
            </div>

            <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-3">
              {loading
                ? <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Creating Account…</>
                : <><span>Create Account</span> <ArrowRight className="w-4 h-4" /></>
              }
            </button>
          </form>

          <p className="text-center text-sm text-slate-500 mt-6">
            Already have an account?{' '}
            <Link to="/login" className="text-brand-600 font-semibold hover:text-brand-700 transition-colors">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

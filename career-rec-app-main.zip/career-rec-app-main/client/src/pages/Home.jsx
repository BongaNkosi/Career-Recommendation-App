import { Link } from 'react-router-dom';
import { GraduationCap, ArrowRight, Target, BookOpen, BarChart3, CheckCircle } from 'lucide-react';

export default function Home() {
  return (
    <div className="min-h-screen bg-navy-950 text-white overflow-hidden">
      {/* Navbar */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-5 max-w-7xl mx-auto">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-brand-600 rounded-xl flex items-center justify-center">
            <GraduationCap className="w-5 h-5 text-white" />
          </div>
          <span className="font-display font-bold text-xl">CareerRec</span>
        </div>
        <div className="flex items-center gap-3">
          <Link to="/login" className="text-white/70 hover:text-white text-sm font-medium transition-colors px-4 py-2">
            Sign In
          </Link>
          <Link to="/register" className="btn-primary btn-sm">Get Started</Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative px-6 pt-20 pb-32 max-w-7xl mx-auto text-center">
        {/* BG orbs */}
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-brand-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-20 right-1/4 w-64 h-64 bg-brand-400/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10">
          <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-brand-600/20 border border-brand-600/30 text-brand-400 text-xs font-semibold uppercase tracking-wider mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-brand-400 animate-pulse" />
            South Africa's Career Guidance Platform
          </span>

          <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold leading-[1.08] mb-6 max-w-4xl mx-auto">
            Find your perfect{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 to-brand-300">
              university programme
            </span>
          </h1>
          <p className="text-white/50 text-lg sm:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
            Enter your matric marks. We calculate your APS score and match you with university programmes you qualify for — in seconds.
          </p>
          <div className="flex items-center justify-center gap-4 flex-wrap">
            <Link to="/register" className="btn-primary btn-lg shadow-lg shadow-brand-900/30">
              Start for Free <ArrowRight className="w-5 h-5" />
            </Link>
            <Link to="/login" className="btn bg-white/10 text-white border border-white/20 hover:bg-white/15 btn-lg">
              Sign In
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-slate-50 py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="font-display text-4xl font-bold text-slate-900 mb-3">How it works</h2>
            <p className="text-slate-500 max-w-xl mx-auto">Three simple steps to discover your ideal academic path</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: BookOpen, title: 'Enter your marks', desc: 'Add your matric subject marks. We support all NSC subjects and automatically calculate your APS score.', color: 'brand' },
              { icon: BarChart3, title: 'Get your APS score', desc: 'Your Admission Point Score is calculated in real-time using the official NSC conversion table.', color: 'blue' },
              { icon: Target, title: 'See matched programmes', desc: 'Browse university programmes you qualify for, ranked by match percentage across all 9 provinces.', color: 'emerald' },
            ].map(({ icon: Icon, title, desc, color }) => (
              <div key={title} className="bg-white rounded-2xl p-8 border border-slate-100 shadow-card hover:shadow-card-hover transition-all duration-300 hover:-translate-y-1">
                <div className={`w-12 h-12 rounded-xl bg-${color === 'brand' ? 'brand-100' : color === 'blue' ? 'blue-100' : 'emerald-100'} flex items-center justify-center mb-5`}>
                  <Icon className={`w-6 h-6 ${color === 'brand' ? 'text-brand-600' : color === 'blue' ? 'text-blue-600' : 'text-emerald-600'}`} />
                </div>
                <h3 className="font-display text-lg font-bold text-slate-900 mb-2">{title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-navy-950 py-20 px-6">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="font-display text-4xl font-bold text-white mb-4">Ready to discover your future?</h2>
          <p className="text-white/50 mb-8">Join thousands of South African learners navigating their career path with CareerRec.</p>
          <div className="flex flex-wrap gap-3 justify-center text-sm text-white/60 mb-8">
            {['Free to use', '500+ programmes', 'All 9 provinces', 'APS calculator'].map(f => (
              <span key={f} className="flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-brand-500" /> {f}
              </span>
            ))}
          </div>
          <Link to="/register" className="btn-primary btn-lg">
            Create Free Account <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}

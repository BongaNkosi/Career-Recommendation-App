import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AppShell } from '../../components/layout/AppShell';
import api from '../../api';
import { Users, Building2, GraduationCap, Send, TrendingUp, ArrowRight, BarChart3 } from 'lucide-react';

export default function AdminDashboard() {
  const [stats,   setStats]   = useState(null);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.get('/reports/admin-stats'), api.get('/reports/summary')])
      .then(([s, sum]) => { setStats(s.data); setSummary(sum.data); })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const statCards = stats ? [
    { label: 'Active Learners',  value: stats.learners,      icon: Users,         color: 'text-brand-600',  bg: 'bg-brand-50',  link: '/admin/learners' },
    { label: 'Institutions',     value: stats.institutions,  icon: Building2,     color: 'text-blue-600',   bg: 'bg-blue-50',   link: '/admin/institutions' },
    { label: 'Programmes',       value: stats.programmes,    icon: GraduationCap, color: 'text-purple-600', bg: 'bg-purple-50', link: '/admin/programmes' },
    { label: 'Applications',     value: stats.applications,  icon: Send,          color: 'text-emerald-600',bg: 'bg-emerald-50',link: '/admin/reports' },
  ] : [];

  return (
    <AppShell>
      <div className="page-header">
        <div>
          <h1 className="page-title">Admin Dashboard</h1>
          <p className="page-subtitle">Platform overview and key metrics</p>
        </div>
        <Link to="/admin/reports" className="btn-secondary">
          <BarChart3 className="w-4 h-4" /> View Reports
        </Link>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48"><div className="spinner" /></div>
      ) : (
        <div className="space-y-6 animate-fade-in">
          {/* Stat cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {statCards.map(({ label, value, icon: Icon, color, bg, link }) => (
              <Link key={label} to={link}
                className="stat-card hover:shadow-card-hover hover:-translate-y-0.5 transition-all duration-200 group">
                <div className={`w-10 h-10 ${bg} rounded-xl flex items-center justify-center mb-3`}>
                  <Icon className={`w-5 h-5 ${color}`} />
                </div>
                <div className="font-display text-3xl font-bold text-slate-900">{value?.toLocaleString()}</div>
                <div className="text-sm text-slate-500">{label}</div>
                <span className={`text-xs ${color} font-medium mt-1 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity`}>
                  Manage <ArrowRight className="w-3 h-3" />
                </span>
              </Link>
            ))}
          </div>

          {/* Bottom grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Top programmes */}
            <div className="glass-card p-6">
              <div className="flex items-center justify-between mb-5">
                <h3 className="font-display font-semibold text-slate-900 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-brand-600" /> Top Programmes by Demand
                </h3>
                <Link to="/admin/reports" className="text-xs text-brand-600 font-semibold hover:underline">View all</Link>
              </div>
              {summary?.topProgrammes?.length ? (
                <div className="space-y-3">
                  {summary.topProgrammes.slice(0, 6).map((p, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-full bg-slate-100 text-slate-500 text-xs font-bold flex items-center justify-center shrink-0">{i+1}</span>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-slate-800 truncate">{p.programme}</div>
                        <div className="text-xs text-slate-500">{p.institution} · APS {p.aps_requirement}</div>
                      </div>
                      <span className="badge badge-brand shrink-0">{p.demand}</span>
                    </div>
                  ))}
                </div>
              ) : <p className="text-slate-400 text-sm">No data yet.</p>}
            </div>

            {/* Learners by province */}
            <div className="glass-card p-6">
              <h3 className="font-display font-semibold text-slate-900 mb-5 flex items-center gap-2">
                <Users className="w-4 h-4 text-brand-600" /> Learners by Province
              </h3>
              {summary?.byProvince?.length ? (
                <div className="space-y-2.5">
                  {summary.byProvince.map(p => {
                    const max = summary.byProvince[0]?.learner_count || 1;
                    const pct = Math.round((p.learner_count / max) * 100);
                    return (
                      <div key={p.province}>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-slate-700 font-medium">{p.province || 'Unknown'}</span>
                          <span className="text-slate-500">{p.learner_count}</span>
                        </div>
                        <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div className="h-full bg-brand-500 rounded-full" style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : <p className="text-slate-400 text-sm">No learner data yet.</p>}
            </div>
          </div>

          {/* Quick links */}
          <div className="glass-card p-6">
            <h3 className="font-display font-semibold text-slate-900 mb-4">Quick Actions</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { to: '/admin/institutions', icon: Building2,     label: 'Add Institution' },
                { to: '/admin/programmes',   icon: GraduationCap, label: 'Add Programme' },
                { to: '/admin/learners',     icon: Users,         label: 'Manage Learners' },
                { to: '/admin/reports',      icon: BarChart3,     label: 'View Reports' },
              ].map(({ to, icon: Icon, label }) => (
                <Link key={to} to={to}
                  className="flex flex-col items-center gap-2 p-4 rounded-xl border border-slate-200 hover:border-brand-300 hover:bg-brand-50 transition-all group text-center">
                  <Icon className="w-5 h-5 text-slate-500 group-hover:text-brand-600 transition-colors" />
                  <span className="text-xs font-medium text-slate-600 group-hover:text-brand-700">{label}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </AppShell>
  );
}

import { useState, useEffect } from 'react';
import { AppShell } from '../../components/layout/AppShell';
import { Modal } from '../../components/ui/Modal';
import { useToast } from '../../hooks/useToast';
import { ToastContainer } from '../../components/ui/Toast';
import api from '../../api';
import { Plus, Pencil, Trash2, Search, Building2, ExternalLink } from 'lucide-react';

const PROVINCES = ['Eastern Cape','Free State','Gauteng','KwaZulu-Natal','Limpopo','Mpumalanga','Northern Cape','North West','Western Cape'];
const TYPES     = ['University','University of Technology','TVET College','Private'];
const EMPTY     = { name:'', abbreviation:'', type:'', province:'', city:'', website:'', logo_url:'', description:'' };

export default function Institutions() {
  const { toasts, toast, removeToast } = useToast();
  const [institutions, setInstitutions] = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [search,   setSearch]   = useState('');
  const [modal,    setModal]    = useState(false);
  const [editing,  setEditing]  = useState(null);
  const [form,     setForm]     = useState(EMPTY);
  const [errors,   setErrors]   = useState({});
  const [saving,   setSaving]   = useState(false);
  const [deleting, setDeleting] = useState(null);

  const fetchAll = () => {
    setLoading(true);
    api.get('/institutions').then(r => setInstitutions(r.data)).catch(() => toast.error('Failed to load.')).finally(() => setLoading(false));
  };
  useEffect(() => { fetchAll(); }, []);

  const openCreate = () => { setEditing(null); setForm(EMPTY); setErrors({}); setModal(true); };
  const openEdit   = (inst) => { setEditing(inst); setForm({ ...inst, logo_url: inst.logo_url || '', website: inst.website || '', description: inst.description || '' }); setErrors({}); setModal(true); };

  const set = (k, v) => { setForm(f => ({ ...f, [k]: v })); setErrors(e => ({ ...e, [k]: '' })); };

  const validate = () => {
    const e = {};
    if (!form.name.trim())         e.name         = 'Required.';
    if (!form.abbreviation.trim()) e.abbreviation = 'Required.';
    if (!form.type)                e.type         = 'Required.';
    if (!form.province)            e.province     = 'Required.';
    if (!form.city.trim())         e.city         = 'Required.';
    return e;
  };

  const handleSave = async () => {
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setSaving(true);
    try {
      if (editing) {
        await api.put(`/institutions/${editing.institution_id}`, form);
        toast.success('Institution updated.');
      } else {
        await api.post('/institutions', form);
        toast.success('Institution created.');
      }
      setModal(false);
      fetchAll();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Save failed.');
    } finally { setSaving(false); }
  };

  const handleDelete = async (inst) => {
    if (!confirm(`Delete "${inst.name}"? This cannot be undone.`)) return;
    setDeleting(inst.institution_id);
    try {
      await api.delete(`/institutions/${inst.institution_id}`);
      toast.success('Deleted.');
      fetchAll();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Delete failed.');
    } finally { setDeleting(null); }
  };

  const filtered = institutions.filter(i =>
    !search || i.name.toLowerCase().includes(search.toLowerCase()) ||
    i.abbreviation.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AppShell>
      <div className="page-header">
        <div>
          <h1 className="page-title">Institutions</h1>
          <p className="page-subtitle">{institutions.length} institutions registered</p>
        </div>
        <button className="btn-primary" onClick={openCreate}>
          <Plus className="w-4 h-4" /> Add Institution
        </button>
      </div>

      {/* Search */}
      <div className="glass-card p-4 mb-6">
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input type="text" className="form-input pl-9" placeholder="Search by name or abbreviation…"
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>
      </div>

      <div className="glass-card overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-48"><div className="spinner" /></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-14 text-slate-400">
            <Building2 className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm">{search ? 'No results.' : 'No institutions yet. Add one!'}</p>
          </div>
        ) : (
          <table className="data-table">
            <thead>
              <tr><th>Institution</th><th>Type</th><th>Province</th><th>City</th><th>Website</th><th className="text-right">Actions</th></tr>
            </thead>
            <tbody>
              {filtered.map(inst => (
                <tr key={inst.institution_id}>
                  <td>
                    <div className="font-semibold text-slate-800">{inst.name}</div>
                    <div className="text-xs text-slate-400">{inst.abbreviation}</div>
                  </td>
                  <td><span className="badge badge-info">{inst.type}</span></td>
                  <td className="text-slate-600">{inst.province}</td>
                  <td className="text-slate-600">{inst.city}</td>
                  <td>
                    {inst.website
                      ? <a href={inst.website} target="_blank" rel="noreferrer" className="text-brand-600 hover:underline inline-flex items-center gap-1 text-xs"><ExternalLink className="w-3 h-3" />Visit</a>
                      : <span className="text-slate-300 text-xs">—</span>
                    }
                  </td>
                  <td>
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => openEdit(inst)} className="p-1.5 text-slate-400 hover:text-brand-600 hover:bg-brand-50 rounded-lg transition-colors">
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button onClick={() => handleDelete(inst)} disabled={deleting === inst.institution_id}
                        className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Modal */}
      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Edit Institution' : 'Add Institution'}>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="form-label">Name <span className="text-red-400">*</span></label>
              <input type="text" className={`form-input ${errors.name?'error':''}`} value={form.name} onChange={e => set('name', e.target.value)} placeholder="University of Pretoria" />
              {errors.name && <p className="form-error">{errors.name}</p>}
            </div>
            <div>
              <label className="form-label">Abbreviation <span className="text-red-400">*</span></label>
              <input type="text" className={`form-input ${errors.abbreviation?'error':''}`} value={form.abbreviation} onChange={e => set('abbreviation', e.target.value)} placeholder="UP" />
              {errors.abbreviation && <p className="form-error">{errors.abbreviation}</p>}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="form-label">Type <span className="text-red-400">*</span></label>
              <select className={`form-input ${errors.type?'error':''}`} value={form.type} onChange={e => set('type', e.target.value)}>
                <option value="">— Select —</option>
                {TYPES.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
              {errors.type && <p className="form-error">{errors.type}</p>}
            </div>
            <div>
              <label className="form-label">Province <span className="text-red-400">*</span></label>
              <select className={`form-input ${errors.province?'error':''}`} value={form.province} onChange={e => set('province', e.target.value)}>
                <option value="">— Select —</option>
                {PROVINCES.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
              {errors.province && <p className="form-error">{errors.province}</p>}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="form-label">City <span className="text-red-400">*</span></label>
              <input type="text" className={`form-input ${errors.city?'error':''}`} value={form.city} onChange={e => set('city', e.target.value)} placeholder="Pretoria" />
              {errors.city && <p className="form-error">{errors.city}</p>}
            </div>
            <div>
              <label className="form-label">Website</label>
              <input type="url" className="form-input" value={form.website} onChange={e => set('website', e.target.value)} placeholder="https://..." />
            </div>
          </div>
          <div>
            <label className="form-label">Description</label>
            <textarea className="form-input min-h-20 resize-y" value={form.description} onChange={e => set('description', e.target.value)} placeholder="Brief description…" rows={3} />
          </div>
          <div className="flex justify-end gap-3 pt-2 border-t border-slate-100">
            <button className="btn-secondary" onClick={() => setModal(false)}>Cancel</button>
            <button className="btn-primary" onClick={handleSave} disabled={saving}>
              {saving ? <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Saving…</> : 'Save Institution'}
            </button>
          </div>
        </div>
      </Modal>

      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </AppShell>
  );
}

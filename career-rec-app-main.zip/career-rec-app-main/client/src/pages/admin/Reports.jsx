import { useState, useEffect } from 'react';
import { AppShell } from '../../components/layout/AppShell';
import api from '../../api';
import { BarChart3, Download, Users, GraduationCap, TrendingUp, Building2 } from 'lucide-react';

const PROVINCES = ['Eastern Cape','Free State','Gauteng','KwaZulu-Natal','Limpopo','Mpumalanga','Northern Cape','North West','Western Cape'];
const FIELDS    = ['Engineering & Technology','Health Sciences','Business & Management','Natural Sciences','Humanities & Social Sciences','Law','Education','Agriculture','Arts & Design','Information Technology'];

export default function Reports() {
  const [tab,     setTab]     = useState('summary');
  const [summary, setSummary] = useState(null);
  const [perf,    setPerf]    = useState([]);
  const [byInst,  setByInst]  = useState([]);
  const [loading, setLoading] = useState(false);
  const [perfYear, setPerfYear]       = useState(new Date().getFullYear());
  const [perfProv, setPerfProv]       = useState('');
  const [instProv, setInstProv]       = useState('');
  const [instField, setInstField]     = useState('');

  useEffect(() => {
    setLoading(true);
    api.get('/reports/summary').then(r => setSummary(r.data)).catch(console.error).finally(() => setLoading(false));
  }, []);

  const fetchPerf = async () => {
    setLoading(true);
    const params = new URLSearchParams({ year: perfYear });
    if (perfProv) params.set('province', perfProv);
    try { const { data } = await api.get(`/reports/learner-performance?${params}`); setPerf(data); }
    catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const fetchByInst = async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (instProv)  params.set('province', instProv);
    if (instField) params.set('field', instField);
    try { const { data } = await api.get(`/reports/by-institution?${params}`); setByInst(data); }
    catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const exportCSV = async (endpoint, filename) => {
    try {
      const resp = await api.get(`${endpoint}?export=csv`, { responseType: 'blob' });
      const url  = URL.createObjectURL(resp.data);
      const a    = document.createElement('a'); a.href = url; a.download = filename; a.click();
      URL.revokeObjectURL(url);
    } catch { alert('Export failed.'); }
  };

  const tabs = [
    { id: 'summary',      label: 'Summary',              icon: BarChart3 },
    { id: 'performance',  label: 'Learner Performance',  icon: Users },
    { id: 'institution',  label: 'By Institution',       icon: Building2 },
  ];

  return (
    <AppShell>
      <div className="page-header">
        <div>
          <h1 className="page-title">Reports</h1>
          <p className="page-subtitle">Analytics and platform insights</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-slate-100 rounded-xl mb-6 w-fit">
        {tabs.map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => setTab(id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              tab === id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
            }`}>
            <Icon className="w-4 h-4" />
            {label}
          </button>
        ))}
      </div>

      {/* SUMMARY */}
      {tab === 'summary' && (
        <div className="space-y-6 animate-fade-in">
          {loading ? (
            <div className="flex items-center justify-center h-48"><div className="spinner" /></div>
          ) : summary && (
            <>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Total Learners',         value: summary.totals?.total_learners,      icon: Users,         color: 'text-brand-600',  bg: 'bg-brand-50'  },
                  { label: 'Total Programmes',        value: summary.totals?.total_programmes,    icon: GraduationCap, color: 'text-purple-600', bg: 'bg-purple-50' },
                  { label: 'Recommendations',         value: summary.totals?.total_recommendations, icon: TrendingUp, color: 'text-blue-600',   bg: 'bg-blue-50'   },
                  { label: 'Applications Submitted',  value: summary.totals?.applied_count,       icon: BarChart3,     color: 'text-emerald-600',bg: 'bg-emerald-50'},
                ].map(({ label, value, icon: Icon, color, bg }) => (
                  <div key={label} className="stat-card">
                    <div className={`w-10 h-10 ${bg} rounded-xl flex items-center justify-center mb-3`}>
                      <Icon className={`w-5 h-5 ${color}`} />
                    </div>
                    <div className="font-display text-3xl font-bold text-slate-900">{value ?? '—'}</div>
                    <div className="text-sm text-slate-500">{label}</div>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="glass-card p-6">
                  <h3 className="font-display font-semibold text-slate-900 mb-4 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-brand-600" /> Top Demanded Programmes
                  </h3>
                  <div className="space-y-2.5">
                    {summary.topProgrammes?.map((p, i) => (
                      <div key={i} className="flex items-center gap-3">
                        <span className="w-6 h-6 rounded-full bg-slate-100 text-slate-500 text-xs font-bold flex items-center justify-center shrink-0">{i+1}</span>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-slate-800 truncate">{p.programme}</div>
                          <div className="text-xs text-slate-500">{p.institution} · {p.field}</div>
                        </div>
                        <span className="badge badge-brand shrink-0">{p.demand} recs</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="glass-card p-6">
                  <h3 className="font-display font-semibold text-slate-900 mb-4 flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-brand-600" /> Recommendations by Field
                  </h3>
                  {summary.byField?.length ? (
                    <div className="space-y-2.5">
                      {summary.byField.map(f => {
                        const max = summary.byField[0]?.count || 1;
                        return (
                          <div key={f.field}>
                            <div className="flex justify-between text-xs mb-1">
                              <span className="text-slate-700 font-medium truncate mr-2">{f.field}</span>
                              <span className="text-slate-500 shrink-0">{f.count}</span>
                            </div>
                            <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                              <div className="h-full bg-brand-500 rounded-full" style={{ width: `${(f.count / max) * 100}%` }} />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : <p className="text-slate-400 text-sm">No data yet.</p>}
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* LEARNER PERFORMANCE */}
      {tab === 'performance' && (
        <div className="space-y-6 animate-fade-in">
          <div className="glass-card p-4 flex flex-wrap gap-3 items-end">
            <div>
              <label className="form-label text-xs">Academic Year</label>
              <input type="number" className="form-input !w-28" value={perfYear} onChange={e => setPerfYear(e.target.value)} />
            </div>
            <div>
              <label className="form-label text-xs">Province</label>
              <select className="form-input !w-auto" value={perfProv} onChange={e => setPerfProv(e.target.value)}>
                <option value="">All</option>
                {PROVINCES.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <button className="btn-primary" onClick={fetchPerf}>Load Report</button>
            {perf.length > 0 && (
              <button className="btn-secondary" onClick={() => exportCSV(`/reports/learner-performance?year=${perfYear}${perfProv?`&province=${perfProv}`:''}`, `learner_perf_${perfYear}.csv`)}>
                <Download className="w-4 h-4" /> Export CSV
              </button>
            )}
          </div>
          {loading ? (
            <div className="flex items-center justify-center h-48"><div className="spinner" /></div>
          ) : perf.length > 0 ? (
            <div className="glass-card overflow-hidden">
              <table className="data-table">
                <thead>
                  <tr><th>Learner</th><th>Province</th><th>Subjects</th><th>Avg Mark</th><th>Year</th></tr>
                </thead>
                <tbody>
                  {perf.map(l => (
                    <tr key={l.user_id}>
                      <td>
                        <div className="font-medium text-slate-800">{l.first_name} {l.last_name}</div>
                        <div className="text-xs text-slate-400">{l.email}</div>
                      </td>
                      <td className="text-slate-600">{l.province || '—'}</td>
                      <td className="text-slate-600">{l.subjects_entered}</td>
                      <td><span className={`font-semibold ${parseFloat(l.average_mark) >= 60 ? 'text-emerald-600' : parseFloat(l.average_mark) >= 40 ? 'text-amber-600' : 'text-red-500'}`}>{l.average_mark}%</span></td>
                      <td className="text-slate-500">{l.academic_year}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="glass-card text-center py-14 text-slate-400">
              <p className="text-sm">Select year & province, then click "Load Report".</p>
            </div>
          )}
        </div>
      )}

      {/* BY INSTITUTION */}
      {tab === 'institution' && (
        <div className="space-y-6 animate-fade-in">
          <div className="glass-card p-4 flex flex-wrap gap-3 items-end">
            <div>
              <label className="form-label text-xs">Province</label>
              <select className="form-input !w-auto" value={instProv} onChange={e => setInstProv(e.target.value)}>
                <option value="">All</option>
                {PROVINCES.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <label className="form-label text-xs">Field</label>
              <select className="form-input !w-auto" value={instField} onChange={e => setInstField(e.target.value)}>
                <option value="">All</option>
                {FIELDS.map(f => <option key={f} value={f}>{f}</option>)}
              </select>
            </div>
            <button className="btn-primary" onClick={fetchByInst}>Load Report</button>
            {byInst.length > 0 && (
              <button className="btn-secondary" onClick={() => exportCSV(`/reports/by-institution${instProv?`?province=${instProv}`:''}`, 'recs_by_institution.csv')}>
                <Download className="w-4 h-4" /> Export CSV
              </button>
            )}
          </div>
          {loading ? (
            <div className="flex items-center justify-center h-48"><div className="spinner" /></div>
          ) : byInst.length > 0 ? (
            <div className="glass-card overflow-hidden">
              <table className="data-table">
                <thead>
                  <tr><th>Institution</th><th>Programme</th><th>Recs</th><th>Applied</th><th>Accepted</th><th>Avg Match</th></tr>
                </thead>
                <tbody>
                  {byInst.map((r, i) => (
                    <tr key={i}>
                      <td>
                        <div className="font-medium text-slate-800">{r.abbreviation}</div>
                        <div className="text-xs text-slate-400">{r.province}</div>
                      </td>
                      <td className="text-slate-700 text-sm">{r.programme}</td>
                      <td className="font-semibold text-brand-600">{r.recommendation_count}</td>
                      <td className="text-slate-600">{r.applied}</td>
                      <td className="text-emerald-600 font-semibold">{r.accepted}</td>
                      <td className="text-slate-600">{r.avg_match_pct ? `${r.avg_match_pct}%` : '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="glass-card text-center py-14 text-slate-400">
              <p className="text-sm">Click "Load Report" to view data.</p>
            </div>
          )}
        </div>
      )}
    </AppShell>
  );
}

import { useState, useEffect } from 'react';
import { AppShell } from '../../components/layout/AppShell';
import { Modal } from '../../components/ui/Modal';
import { useToast } from '../../hooks/useToast';
import { ToastContainer } from '../../components/ui/Toast';
import api from '../../api';
import { Plus, Pencil, Trash2, Search, GraduationCap } from 'lucide-react';

const FIELDS = ['Engineering & Technology','Health Sciences','Business & Management','Natural Sciences','Humanities & Social Sciences','Law','Education','Agriculture','Arts & Design','Information Technology'];
const EMPTY  = { name:'', faculty:'', institution_id:'', aps_requirement:'', duration_years:3, nqf_level:7, field:'', description:'' };

export default function Programmes() {
  const { toasts, toast, removeToast } = useToast();
  const [programmes,    setProgrammes]    = useState([]);
  const [institutions,  setInstitutions]  = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [search,    setSearch]    = useState('');
  const [fieldFilter, setFieldFilter] = useState('');
  const [modal,     setModal]     = useState(false);
  const [editing,   setEditing]   = useState(null);
  const [form,      setForm]      = useState(EMPTY);
  const [errors,    setErrors]    = useState({});
  const [saving,    setSaving]    = useState(false);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [p, i] = await Promise.all([api.get('/programmes'), api.get('/institutions')]);
      setProgrammes(p.data); setInstitutions(i.data);
    } catch { toast.error('Failed to load.'); }
    finally { setLoading(false); }
  };
  useEffect(() => { fetchAll(); }, []);

  const openCreate = () => { setEditing(null); setForm(EMPTY); setErrors({}); setModal(true); };
  const openEdit   = (p)  => { setEditing(p); setForm({ name: p.name, faculty: p.faculty||'', institution_id: p.institution_id, aps_requirement: p.aps_requirement, duration_years: p.duration_years, nqf_level: p.nqf_level||7, field: p.field, description: p.description||'' }); setErrors({}); setModal(true); };
  const set = (k, v) => { setForm(f => ({ ...f, [k]: v })); setErrors(e => ({ ...e, [k]: '' })); };

  const validate = () => {
    const e = {};
    if (!form.name.trim())       e.name         = 'Required.';
    if (!form.institution_id)    e.institution_id= 'Required.';
    if (!form.aps_requirement)   e.aps_requirement = 'Required.';
    if (!form.field)             e.field        = 'Required.';
    if (!form.duration_years)    e.duration_years = 'Required.';
    const aps = parseInt(form.aps_requirement);
    if (isNaN(aps) || aps < 1 || aps > 42) e.aps_requirement = 'Must be 1–42.';
    return e;
  };

  const handleSave = async () => {
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setSaving(true);
    try {
      const payload = { ...form, aps_requirement: parseInt(form.aps_requirement), duration_years: parseInt(form.duration_years), nqf_level: parseInt(form.nqf_level) };
      if (editing) { await api.put(`/programmes/${editing.programme_id}`, payload); toast.success('Programme updated.'); }
      else         { await api.post('/programmes', payload); toast.success('Programme created.'); }
      setModal(false); fetchAll();
    } catch (err) { toast.error(err.response?.data?.message || 'Save failed.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (p) => {
    if (!confirm(`Delete "${p.name}"?`)) return;
    try { await api.delete(`/programmes/${p.programme_id}`); toast.success('Deleted.'); fetchAll(); }
    catch (err) { toast.error(err.response?.data?.message || 'Delete failed.'); }
  };

  const filtered = programmes.filter(p =>
    (!search || p.name.toLowerCase().includes(search.toLowerCase()) || p.institution?.name?.toLowerCase().includes(search.toLowerCase())) &&
    (!fieldFilter || p.field === fieldFilter)
  );

  return (
    <AppShell>
      <div className="page-header">
        <div>
          <h1 className="page-title">Programmes</h1>
          <p className="page-subtitle">{programmes.length} programmes registered</p>
        </div>
        <button className="btn-primary" onClick={openCreate}><Plus className="w-4 h-4" /> Add Programme</button>
      </div>

      <div className="glass-card p-4 mb-6 flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input type="text" className="form-input pl-9" placeholder="Search programmes…"
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <select className="form-input !w-auto" value={fieldFilter} onChange={e => setFieldFilter(e.target.value)}>
          <option value="">All Fields</option>
          {FIELDS.map(f => <option key={f} value={f}>{f}</option>)}
        </select>
      </div>

      <div className="glass-card overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-48"><div className="spinner" /></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-14 text-slate-400">
            <GraduationCap className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No programmes found.</p>
          </div>
        ) : (
          <table className="data-table">
            <thead>
              <tr><th>Programme</th><th>Institution</th><th>Field</th><th>APS</th><th>Duration</th><th className="text-right">Actions</th></tr>
            </thead>
            <tbody>
              {filtered.map(p => (
                <tr key={p.programme_id}>
                  <td>
                    <div className="font-semibold text-slate-800">{p.name}</div>
                    {p.faculty && <div className="text-xs text-slate-400">{p.faculty}</div>}
                  </td>
                  <td>
                    <div className="text-sm text-slate-700">{p.institution?.abbreviation || '—'}</div>
                    <div className="text-xs text-slate-400">{p.institution?.province}</div>
                  </td>
                  <td><span className="badge badge-neutral text-xs">{p.field}</span></td>
                  <td className="font-semibold text-brand-600">{p.aps_requirement}</td>
                  <td className="text-slate-600">{p.duration_years} yr{p.duration_years > 1 ? 's' : ''}</td>
                  <td>
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => openEdit(p)} className="p-1.5 text-slate-400 hover:text-brand-600 hover:bg-brand-50 rounded-lg transition-colors"><Pencil className="w-4 h-4" /></button>
                      <button onClick={() => handleDelete(p)} className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Edit Programme' : 'Add Programme'} size="lg">
        <div className="space-y-4">
          <div>
            <label className="form-label">Programme Name <span className="text-red-400">*</span></label>
            <input type="text" className={`form-input ${errors.name?'error':''}`} value={form.name} onChange={e => set('name', e.target.value)} placeholder="BSc Computer Science" />
            {errors.name && <p className="form-error">{errors.name}</p>}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="form-label">Institution <span className="text-red-400">*</span></label>
              <select className={`form-input ${errors.institution_id?'error':''}`} value={form.institution_id} onChange={e => set('institution_id', e.target.value)}>
                <option value="">— Select —</option>
                {institutions.map(i => <option key={i.institution_id} value={i.institution_id}>{i.name}</option>)}
              </select>
              {errors.institution_id && <p className="form-error">{errors.institution_id}</p>}
            </div>
            <div>
              <label className="form-label">Field of Study <span className="text-red-400">*</span></label>
              <select className={`form-input ${errors.field?'error':''}`} value={form.field} onChange={e => set('field', e.target.value)}>
                <option value="">— Select —</option>
                {FIELDS.map(f => <option key={f} value={f}>{f}</option>)}
              </select>
              {errors.field && <p className="form-error">{errors.field}</p>}
            </div>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="form-label">APS Requirement <span className="text-red-400">*</span></label>
              <input type="number" min="1" max="42" className={`form-input ${errors.aps_requirement?'error':''}`} value={form.aps_requirement} onChange={e => set('aps_requirement', e.target.value)} />
              {errors.aps_requirement && <p className="form-error">{errors.aps_requirement}</p>}
            </div>
            <div>
              <label className="form-label">Duration (Years)</label>
              <input type="number" min="1" max="7" className="form-input" value={form.duration_years} onChange={e => set('duration_years', e.target.value)} />
            </div>
            <div>
              <label className="form-label">NQF Level</label>
              <input type="number" min="5" max="10" className="form-input" value={form.nqf_level} onChange={e => set('nqf_level', e.target.value)} />
            </div>
          </div>
          <div>
            <label className="form-label">Faculty</label>
            <input type="text" className="form-input" value={form.faculty} onChange={e => set('faculty', e.target.value)} placeholder="Faculty of Science" />
          </div>
          <div>
            <label className="form-label">Description</label>
            <textarea className="form-input resize-y min-h-20" rows={3} value={form.description} onChange={e => set('description', e.target.value)} placeholder="Programme description…" />
          </div>
          <div className="flex justify-end gap-3 pt-2 border-t border-slate-100">
            <button className="btn-secondary" onClick={() => setModal(false)}>Cancel</button>
            <button className="btn-primary" onClick={handleSave} disabled={saving}>
              {saving ? <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Saving…</> : 'Save Programme'}
            </button>
          </div>
        </div>
      </Modal>

      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </AppShell>
  );
}

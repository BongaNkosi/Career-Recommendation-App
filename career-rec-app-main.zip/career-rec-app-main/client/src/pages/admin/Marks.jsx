import { useState, useEffect } from 'react';
import { AppShell } from '../../components/layout/AppShell';
import { useToast } from '../../hooks/useToast';
import { ToastContainer } from '../../components/ui/Toast';
import api from '../../api';
import { Search, ClipboardList, Trash2 } from 'lucide-react';

const markToAPS = (m) => {
  if (m >= 90) return 7; if (m >= 80) return 6; if (m >= 70) return 5;
  if (m >= 60) return 4; if (m >= 50) return 3; if (m >= 40) return 2; return 1;
};

export default function AdminMarks() {
  const { toasts, toast, removeToast } = useToast();
  const [marks,   setMarks]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [search,  setSearch]  = useState('');

  const fetchAll = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/marks');
      setMarks(data);
    } catch { toast.error('Failed to load marks.'); }
    finally  { setLoading(false); }
  };
  useEffect(() => { fetchAll(); }, []);

  const handleDelete = async (markId) => {
    if (!confirm('Delete this mark record?')) return;
    try { await api.delete(`/marks/${markId}`); toast.success('Deleted.'); fetchAll(); }
    catch { toast.error('Failed to delete.'); }
  };

  const filtered = marks.filter(m =>
    !search || `${m.user?.first_name} ${m.user?.last_name} ${m.user?.email} ${m.subject?.name}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AppShell>
      <div className="page-header">
        <div>
          <h1 className="page-title">Marks Overview</h1>
          <p className="page-subtitle">All learner subject marks across the platform</p>
        </div>
      </div>

      <div className="glass-card p-4 mb-6">
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input type="text" className="form-input pl-9" placeholder="Search learner or subject…"
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>
      </div>

      <div className="glass-card overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-48"><div className="spinner" /></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-14 text-slate-400">
            <ClipboardList className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No marks found.</p>
          </div>
        ) : (
          <table className="data-table">
            <thead>
              <tr><th>Learner</th><th>Subject</th><th>Mark</th><th>APS Pts</th><th>Year</th><th>Type</th><th className="text-right">Actions</th></tr>
            </thead>
            <tbody>
              {filtered.map(m => (
                <tr key={m.mark_id}>
                  <td>
                    <div className="font-medium text-slate-800">{m.user?.first_name} {m.user?.last_name}</div>
                    <div className="text-xs text-slate-400">{m.user?.email}</div>
                  </td>
                  <td className="text-slate-700">{m.subject?.name}</td>
                  <td>
                    <span className={`font-semibold ${parseFloat(m.mark) >= 60 ? 'text-emerald-600' : parseFloat(m.mark) >= 40 ? 'text-amber-600' : 'text-red-500'}`}>
                      {m.mark}%
                    </span>
                  </td>
                  <td>
                    <span className="w-6 h-6 rounded-full bg-brand-100 text-brand-700 text-xs font-bold inline-flex items-center justify-center">
                      {markToAPS(parseFloat(m.mark))}
                    </span>
                  </td>
                  <td className="text-slate-600">{m.academic_year}</td>
                  <td>
                    <span className={`badge ${m.subject?.subject_type === 'compulsory' ? 'badge-info' : 'badge-neutral'}`}>
                      {m.subject?.subject_type}
                    </span>
                  </td>
                  <td>
                    <div className="flex justify-end">
                      <button onClick={() => handleDelete(m.mark_id)} className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </AppShell>
  );
}

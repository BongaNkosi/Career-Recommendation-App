import { useState, useEffect } from 'react';
import { AppShell } from '../../components/layout/AppShell';
import { Modal } from '../../components/ui/Modal';
import { useToast } from '../../hooks/useToast';
import { ToastContainer } from '../../components/ui/Toast';
import api from '../../api';
import { Plus, Pencil, Trash2, Search, Users, ToggleLeft, ToggleRight } from 'lucide-react';

const PROVINCES = ['Eastern Cape','Free State','Gauteng','KwaZulu-Natal','Limpopo','Mpumalanga','Northern Cape','North West','Western Cape'];
const EMPTY     = { firstName:'', lastName:'', email:'', password:'', province:'', gender:'', dateOfBirth:'', isActive: true };

export default function Learners() {
  const { toasts, toast, removeToast } = useToast();
  const [learners,  setLearners]  = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [search,    setSearch]    = useState('');
  const [province,  setProvince]  = useState('');
  const [modal,     setModal]     = useState(false);
  const [editing,   setEditing]   = useState(null);
  const [form,      setForm]      = useState(EMPTY);
  const [errors,    setErrors]    = useState({});
  const [saving,    setSaving]    = useState(false);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (province) params.set('province', province);
      if (search)   params.set('search', search);
      const { data } = await api.get(`/learners?${params}`);
      setLearners(data);
    } catch { toast.error('Failed to load learners.'); }
    finally  { setLoading(false); }
  };
  useEffect(() => { fetchAll(); }, [province]);

  const openCreate = () => { setEditing(null); setForm(EMPTY); setErrors({}); setModal(true); };
  const openEdit   = (l)  => { setEditing(l); setForm({ firstName: l.first_name, lastName: l.last_name, email: l.email, password: '', province: l.province||'', gender: l.gender||'', dateOfBirth: l.date_of_birth||'', isActive: l.is_active }); setErrors({}); setModal(true); };
  const set = (k, v) => { setForm(f => ({ ...f, [k]: v })); setErrors(e => ({ ...e, [k]: '' })); };

  const validate = () => {
    const e = {};
    if (!form.firstName.trim()) e.firstName = 'Required.';
    if (!form.lastName.trim())  e.lastName  = 'Required.';
    if (!form.email.trim())     e.email     = 'Required.';
    if (!editing && !form.password) e.password = 'Password required for new learners.';
    if (!editing && form.password && form.password.length < 8) e.password = 'Min. 8 characters.';
    return e;
  };

  const handleSave = async () => {
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setSaving(true);
    try {
      if (editing) { await api.put(`/learners/${editing.user_id}`, form); toast.success('Learner updated.'); }
      else         { await api.post('/learners', form);                   toast.success('Learner created.'); }
      setModal(false); fetchAll();
    } catch (err) { toast.error(err.response?.data?.message || 'Save failed.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (l) => {
    if (!confirm(`Delete "${l.first_name} ${l.last_name}"? This will remove all their marks and recommendations.`)) return;
    try { await api.delete(`/learners/${l.user_id}`); toast.success('Learner deleted.'); fetchAll(); }
    catch (err) { toast.error(err.response?.data?.message || 'Delete failed.'); }
  };

  const filtered = learners.filter(l =>
    !search || `${l.first_name} ${l.last_name} ${l.email}`.toLowerCase().includes(search.toLowerCase())
  );

  const fmt = (d) => d ? new Date(d).toLocaleDateString('en-ZA') : '—';

  return (
    <AppShell>
      <div className="page-header">
        <div>
          <h1 className="page-title">Learners</h1>
          <p className="page-subtitle">{learners.length} registered learners</p>
        </div>
        <button className="btn-primary" onClick={openCreate}><Plus className="w-4 h-4" /> Add Learner</button>
      </div>

      <div className="glass-card p-4 mb-6 flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input type="text" className="form-input pl-9" placeholder="Search by name or email…"
            value={search} onChange={e => setSearch(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && fetchAll()} />
        </div>
        <select className="form-input !w-auto" value={province} onChange={e => setProvince(e.target.value)}>
          <option value="">All Provinces</option>
          {PROVINCES.map(p => <option key={p} value={p}>{p}</option>)}
        </select>
        <button className="btn-secondary" onClick={fetchAll}>Search</button>
      </div>

      <div className="glass-card overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-48"><div className="spinner" /></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-14 text-slate-400">
            <Users className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No learners found.</p>
          </div>
        ) : (
          <table className="data-table">
            <thead>
              <tr><th>Learner</th><th>Province</th><th>Gender</th><th>Registered</th><th>Status</th><th className="text-right">Actions</th></tr>
            </thead>
            <tbody>
              {filtered.map(l => (
                <tr key={l.user_id}>
                  <td>
                    <div className="font-semibold text-slate-800">{l.first_name} {l.last_name}</div>
                    <div className="text-xs text-slate-400">{l.email}</div>
                  </td>
                  <td className="text-slate-600">{l.province || '—'}</td>
                  <td className="text-slate-600 capitalize">{l.gender?.replace(/_/g,' ') || '—'}</td>
                  <td className="text-slate-500 text-sm">{fmt(l.created_at)}</td>
                  <td>
                    <span className={`badge ${l.is_active ? 'badge-success' : 'badge-danger'}`}>
                      {l.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => openEdit(l)} className="p-1.5 text-slate-400 hover:text-brand-600 hover:bg-brand-50 rounded-lg transition-colors"><Pencil className="w-4 h-4" /></button>
                      <button onClick={() => handleDelete(l)} className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <Modal open={modal} onClose={() => setModal(false)} title={editing ? 'Edit Learner' : 'Add Learner'}>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="form-label">First Name <span className="text-red-400">*</span></label>
              <input type="text" className={`form-input ${errors.firstName?'error':''}`} value={form.firstName} onChange={e => set('firstName', e.target.value)} />
              {errors.firstName && <p className="form-error">{errors.firstName}</p>}
            </div>
            <div>
              <label className="form-label">Last Name <span className="text-red-400">*</span></label>
              <input type="text" className={`form-input ${errors.lastName?'error':''}`} value={form.lastName} onChange={e => set('lastName', e.target.value)} />
              {errors.lastName && <p className="form-error">{errors.lastName}</p>}
            </div>
          </div>
          <div>
            <label className="form-label">Email <span className="text-red-400">*</span></label>
            <input type="email" className={`form-input ${errors.email?'error':''}`} value={form.email} onChange={e => set('email', e.target.value)} />
            {errors.email && <p className="form-error">{errors.email}</p>}
          </div>
          {!editing && (
            <div>
              <label className="form-label">Password <span className="text-red-400">*</span></label>
              <input type="password" className={`form-input ${errors.password?'error':''}`} value={form.password} onChange={e => set('password', e.target.value)} placeholder="Min. 8 characters" />
              {errors.password && <p className="form-error">{errors.password}</p>}
            </div>
          )}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="form-label">Province</label>
              <select className="form-input" value={form.province} onChange={e => set('province', e.target.value)}>
                <option value="">— Select —</option>
                {PROVINCES.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <label className="form-label">Gender</label>
              <select className="form-input" value={form.gender} onChange={e => set('gender', e.target.value)}>
                <option value="">— Select —</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
                <option value="prefer_not_to_say">Prefer not to say</option>
              </select>
            </div>
          </div>
          {editing && (
            <label className="flex items-center gap-3 cursor-pointer">
              <div className={`relative w-10 h-6 rounded-full transition-colors ${form.isActive ? 'bg-brand-500' : 'bg-slate-300'}`}
                onClick={() => set('isActive', !form.isActive)}>
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform ${form.isActive ? 'translate-x-5' : 'translate-x-1'}`} />
              </div>
              <span className="text-sm font-medium text-slate-700">Account Active</span>
            </label>
          )}
          <div className="flex justify-end gap-3 pt-2 border-t border-slate-100">
            <button className="btn-secondary" onClick={() => setModal(false)}>Cancel</button>
            <button className="btn-primary" onClick={handleSave} disabled={saving}>
              {saving ? <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Saving…</> : 'Save Learner'}
            </button>
          </div>
        </div>
      </Modal>

      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </AppShell>
  );
}

import { useState, useEffect } from 'react';
import { AppShell } from '../../components/layout/AppShell';
import api from '../../api';
import { Plus, Trash2, BookOpen, Save, RefreshCw, Info } from 'lucide-react';
import { useToast } from '../../hooks/useToast';
import { ToastContainer } from '../../components/ui/Toast';

const YEAR = new Date().getFullYear();
const YEARS = [YEAR, YEAR - 1, YEAR - 2];

const markToAPS = (m) => {
  if (m >= 80) return 7; if (m >= 70) return 6; if (m >= 60) return 5;
  if (m >= 50) return 4; if (m >= 40) return 3; if (m >= 30) return 2;
  return 1;
};
const apsColor = (p) => p >= 70 ? 'text-emerald-600' : p >= 50 ? 'text-amber-600' : 'text-red-500';

export default function EnterMarks() {
  const { toasts, toast, removeToast } = useToast();
  const [subjects, setSubjects]   = useState([]);
  const [myMarks,  setMyMarks]    = useState([]);
  const [year,     setYear]       = useState(YEAR);
  const [loading,  setLoading]    = useState(true);
  const [saving,   setSaving]     = useState(null);
  const [newEntry, setNewEntry]   = useState({ subject_id: '', mark: '', grade: 12 });

  const fetchData = async () => {
    setLoading(true);
    try {
      const [subj, marks] = await Promise.all([
        api.get('/marks/subjects'),
        api.get('/marks'),
      ]);
      setSubjects(subj.data);
      setMyMarks(marks.data.filter(m => m.academic_year === year));
    } catch { toast.error('Failed to load marks.'); }
    finally  { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, [year]);

  const handleSave = async () => {
    if (!newEntry.subject_id || newEntry.mark === '') { toast.error('Select a subject and enter a mark.'); return; }
    const mark = parseFloat(newEntry.mark);
    if (isNaN(mark) || mark < 0 || mark > 100) { toast.error('Mark must be 0–100.'); return; }
    setSaving('new');
    try {
      await api.post('/marks', { subject_id: newEntry.subject_id, mark, grade: newEntry.grade, academic_year: year });
      toast.success('Mark saved!');
      setNewEntry({ subject_id: '', mark: '', grade: 12 });
      await fetchData();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed to save mark.'); }
    finally { setSaving(null); }
  };

  const handleDelete = async (markId) => {
    if (!confirm('Delete this mark?')) return;
    setSaving(markId);
    try {
      await api.delete(`/marks/${markId}`);
      toast.success('Mark deleted.');
      await fetchData();
    } catch { toast.error('Failed to delete.'); }
    finally  { setSaving(null); }
  };

  const handleInlineUpdate = async (markId, newMark) => {
    const mark = parseFloat(newMark);
    if (isNaN(mark) || mark < 0 || mark > 100) return;
    setSaving(markId);
    try {
      await api.put(`/marks/${markId}`, { mark, academic_year: year });
      await fetchData();
    } catch { toast.error('Failed to update mark.'); }
    finally { setSaving(null); }
  };

  // APS calculation
  const topSix = [...myMarks]
    .filter(m => !m.subject?.name?.toLowerCase().includes('life orientation'))
    .sort((a,b) => markToAPS(parseFloat(b.mark)) - markToAPS(parseFloat(a.mark)))
    .slice(0, 6);
  const apsScore = topSix.reduce((s, m) => s + markToAPS(parseFloat(m.mark)), 0);

  const usedSubjectIds = new Set(myMarks.map(m => m.subject_id));
  const availableSubjects = subjects.filter(s => !usedSubjectIds.has(s.subject_id));

  return (
    <AppShell>
      <div className="page-header">
        <div>
          <h1 className="page-title">My Marks</h1>
          <p className="page-subtitle">Enter your matric subject marks for APS calculation</p>
        </div>
        <div className="flex items-center gap-3">
          <select className="form-input !w-auto" value={year} onChange={e => setYear(parseInt(e.target.value))}>
            {YEARS.map(y => <option key={y} value={y}>{y}</option>)}
          </select>
          <button onClick={fetchData} className="btn-secondary">
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* APS Summary */}
        <div className="lg:col-span-1 space-y-4">
          <div className="glass-card p-6">
            <div className="flex items-center gap-2 mb-4">
              <BookOpen className="w-4 h-4 text-brand-600" />
              <h3 className="font-display font-semibold text-slate-900">APS Summary</h3>
            </div>
            <div className="text-center py-4 border-b border-slate-100 mb-4">
              <div className="font-display text-6xl font-bold text-brand-600">{apsScore}</div>
              <div className="text-slate-400 text-sm mt-1">/ 50 points</div>
            </div>
            <div className="space-y-2 text-sm">
              {topSix.map((m, i) => (
                <div key={m.mark_id} className="flex items-center justify-between py-1.5 border-b border-slate-50 last:border-0">
                  <span className="text-slate-600 truncate flex-1 mr-2 text-xs">{m.subject?.name}</span>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className={`text-xs font-bold ${apsColor(parseFloat(m.mark))}`}>{m.mark}%</span>
                    <span className="w-5 h-5 rounded-full bg-brand-100 text-brand-700 text-xs font-bold flex items-center justify-center">
                      {markToAPS(parseFloat(m.mark))}
                    </span>
                  </div>
                </div>
              ))}
              {topSix.length === 0 && (
                <p className="text-slate-400 text-xs text-center py-2">No marks entered yet</p>
              )}
            </div>
          </div>

          {/* APS scale reference */}
          <div className="glass-card p-5">
            <div className="flex items-center gap-2 mb-3">
              <Info className="w-4 h-4 text-blue-500" />
              <h4 className="text-sm font-semibold text-slate-700">APS Points Scale</h4>
            </div>
            <div className="space-y-1.5 text-xs text-slate-600">
              {[['80–100%','7 pts'],['70–79%','6 pts'],['60–69%','5 pts'],['50–59%','4 pts'],['40–49%','3 pts'],['30–39%','2 pts'],['0–29%','1 pt']].map(([r,p]) => (
                <div key={r} className="flex justify-between">
                  <span>{r}</span><span className="font-semibold text-brand-600">{p}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Marks table */}
        <div className="lg:col-span-2 space-y-4">
          {/* Add new mark */}
          <div className="glass-card p-5">
            <h3 className="font-display font-semibold text-slate-900 mb-4 flex items-center gap-2">
              <Plus className="w-4 h-4 text-brand-600" /> Add Subject Mark
            </h3>
            <div className="flex flex-col sm:flex-row gap-3">
              <select className="form-input flex-1" value={newEntry.subject_id}
                onChange={e => setNewEntry(p => ({ ...p, subject_id: e.target.value }))}>
                <option value="">— Select Subject —</option>
                {['compulsory','elective'].map(type => (
                  <optgroup key={type} label={type.charAt(0).toUpperCase() + type.slice(1)}>
                    {availableSubjects.filter(s => s.subject_type === type).map(s => (
                      <option key={s.subject_id} value={s.subject_id}>{s.name}</option>
                    ))}
                  </optgroup>
                ))}
              </select>
              <input type="number" min="0" max="100" placeholder="Mark (0–100)"
                className="form-input w-36" value={newEntry.mark}
                onChange={e => setNewEntry(p => ({ ...p, mark: e.target.value }))} />
              <button className="btn-primary shrink-0" onClick={handleSave} disabled={saving === 'new'}>
                {saving === 'new'
                  ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  : <><Save className="w-4 h-4" /> Save</>
                }
              </button>
            </div>
          </div>

          {/* Existing marks */}
          <div className="glass-card overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-display font-semibold text-slate-900">
                Marks for {year} <span className="text-slate-400 font-normal text-sm">({myMarks.length} subjects)</span>
              </h3>
            </div>
            {loading ? (
              <div className="flex items-center justify-center h-32"><div className="spinner" /></div>
            ) : myMarks.length === 0 ? (
              <div className="text-center py-14 text-slate-400">
                <BookOpen className="w-10 h-10 mx-auto mb-3 opacity-30" />
                <p className="text-sm">No marks entered for {year} yet.</p>
              </div>
            ) : (
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Subject</th>
                    <th>Type</th>
                    <th>Mark (%)</th>
                    <th>APS Pts</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {myMarks.map(m => (
                    <tr key={m.mark_id}>
                      <td className="font-medium text-slate-800">{m.subject?.name}</td>
                      <td>
                        <span className={`badge ${m.subject?.subject_type === 'compulsory' ? 'badge-info' : 'badge-neutral'}`}>
                          {m.subject?.subject_type}
                        </span>
                      </td>
                      <td>
                        <input type="number" min="0" max="100"
                          defaultValue={m.mark}
                          className="w-20 px-2 py-1 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-400"
                          onBlur={e => {
                            if (e.target.value !== String(m.mark)) handleInlineUpdate(m.mark_id, e.target.value);
                          }}
                        />
                      </td>
                      <td>
                        <span className={`font-bold text-sm ${apsColor(parseFloat(m.mark))}`}>
                          {markToAPS(parseFloat(m.mark))}
                        </span>
                      </td>
                      <td>
                        <button onClick={() => handleDelete(m.mark_id)} disabled={saving === m.mark_id}
                          className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                          {saving === m.mark_id
                            ? <span className="w-3 h-3 border-2 border-slate-300 border-t-slate-600 rounded-full animate-spin inline-block" />
                            : <Trash2 className="w-4 h-4" />
                          }
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>
      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </AppShell>
  );
}
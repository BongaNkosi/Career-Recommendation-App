import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { AppShell } from '../../components/layout/AppShell';
import api from '../../api';
import { BookOpen, Target, Clock, CheckCircle, ArrowRight, TrendingUp, Zap } from 'lucide-react';

const markToAPS = (mark) => {
  if (mark >= 80) return 7; if (mark >= 70) return 6; if (mark >= 60) return 5;
  if (mark >= 50) return 4; if (mark >= 40) return 3; if (mark >= 30) return 2;
  return 1;
};

const APSLabel = (score) => {
  if (score >= 35) return { label: 'Excellent', cls: 'badge-success' };
  if (score >= 28) return { label: 'Good',      cls: 'badge-brand' };
  if (score >= 20) return { label: 'Average',   cls: 'badge-warning' };
  return { label: 'Below Average', cls: 'badge-danger' };
};

export default function LearnerDashboard() {
  const { user } = useAuth();
  const [data, setData]     = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.get('/marks'), api.get('/recommendations')])
      .then(([marksRes, recsRes]) => {
        const marks = marksRes.data;
        const recs  = recsRes.data;
        const eligible = marks
          .filter(m => !m.subject?.name?.toLowerCase().includes('life orientation'))
          .sort((a,b) => markToAPS(b.mark) - markToAPS(a.mark))
          .slice(0, 6);
        const apsScore = eligible.reduce((s, m) => s + markToAPS(parseFloat(m.mark)), 0);
        setData({ apsScore, marks, recs });
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const apsLabel = data ? APSLabel(data.apsScore) : null;

  return (
    <AppShell>
      <div className="page-header">
        <div>
          <h1 className="page-title">Welcome back, {user?.firstName}! 👋</h1>
          <p className="page-subtitle">Your academic journey at a glance</p>
        </div>
        <Link to="/learner/marks" className="btn-primary">
          <Zap className="w-4 h-4" /> Enter Marks
        </Link>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48"><div className="spinner" /></div>
      ) : (
        <div className="space-y-6 animate-fade-in">
          {/* APS Hero Card */}
          <div className="rounded-2xl bg-gradient-to-br from-navy-900 via-navy-800 to-brand-900 p-8 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-brand-500/10 rounded-full blur-3xl translate-x-1/3 -translate-y-1/3" />
            <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
              <div>
                <p className="text-white/50 text-xs uppercase tracking-widest mb-2">Your APS Score</p>
                <div className="flex items-baseline gap-2 mb-3">
                  <span className="font-display text-7xl font-bold">{data?.apsScore || 0}</span>
                  <span className="text-white/40 text-2xl">/50</span>
                </div>
                <span className={`badge ${apsLabel?.cls} text-sm px-3 py-1`}>{apsLabel?.label}</span>
                <p className="mt-3 text-white/40 text-xs">Based on top 6 subjects (excl. Life Orientation)</p>
              </div>
              {/* APS progress ring */}
              <div className="shrink-0">
                <div className="relative w-32 h-32">
                  <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                    <circle cx="18" cy="18" r="15.9" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="2.5" />
                    <circle cx="18" cy="18" r="15.9" fill="none" stroke="currentColor"
                      className="text-brand-400" strokeWidth="2.5" strokeLinecap="round"
                      strokeDasharray={`${((data?.apsScore || 0) / 50) * 100}, 100`} />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="font-display text-2xl font-bold">{Math.round(((data?.apsScore || 0) / 50) * 100)}%</span>
                    <span className="text-white/40 text-[10px]">of max</span>
                  </div>
                </div>
              </div>
            </div>
            {/* APS progress bar */}
            <div className="relative z-10 mt-6">
              <div className="flex justify-between text-[10px] text-white/30 mb-1.5">
                <span>0</span><span>APS 20 (Entry)</span><span>APS 28 (Degree)</span><span>50</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-brand-600 to-brand-400 rounded-full transition-all duration-1000"
                  style={{ width: `${((data?.apsScore || 0) / 50) * 100}%` }} />
              </div>
            </div>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Subjects Entered', value: data?.marks?.length || 0, icon: BookOpen, color: 'text-brand-600', bg: 'bg-brand-50', link: '/learner/marks' },
              { label: 'Recommendations', value: data?.recs?.length || 0, icon: Target, color: 'text-purple-600', bg: 'bg-purple-50', link: '/learner/recommendations' },
              { label: 'Pending Review', value: data?.recs?.filter(r => r.status === 'generated').length || 0, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50', link: '/learner/recommendations' },
              { label: 'Accepted', value: data?.recs?.filter(r => r.status === 'accepted').length || 0, icon: CheckCircle, color: 'text-emerald-600', bg: 'bg-emerald-50', link: '/learner/recommendations' },
            ].map(({ label, value, icon: Icon, color, bg, link }) => (
              <Link key={label} to={link} className="stat-card hover:shadow-card-hover hover:-translate-y-0.5 transition-all duration-200 group">
                <div className={`w-10 h-10 ${bg} rounded-xl flex items-center justify-center mb-3`}>
                  <Icon className={`w-5 h-5 ${color}`} />
                </div>
                <div className="font-display text-3xl font-bold text-slate-900">{value}</div>
                <div className="text-sm text-slate-500">{label}</div>
                <span className={`text-xs ${color} font-medium mt-1 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity`}>
                  View <ArrowRight className="w-3 h-3" />
                </span>
              </Link>
            ))}
          </div>

          {/* Bottom grid: Quick actions + Recent recs */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Quick actions */}
            <div className="glass-card p-6">
              <h3 className="font-display font-semibold text-slate-900 mb-4 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-brand-600" /> Quick Actions
              </h3>
              <div className="space-y-2">
                {[
                  { to: '/learner/marks', icon: BookOpen, label: 'Enter / Update Marks', desc: 'Add your matric subject marks' },
                  { to: '/learner/recommendations', icon: Target, label: 'View Recommendations', desc: 'See matched programmes' },
                  { to: '/learner/programmes', icon: BookOpen, label: 'Browse All Programmes', desc: 'Explore all available options' },
                ].map(({ to, icon: Icon, label, desc }) => (
                  <Link key={to} to={to}
                    className="flex items-center gap-4 p-3.5 rounded-xl bg-slate-50 hover:bg-brand-50 hover:border-brand-100 border border-transparent transition-all group">
                    <div className="w-9 h-9 bg-white rounded-lg border border-slate-200 flex items-center justify-center shrink-0 group-hover:border-brand-200 group-hover:bg-brand-50 transition-colors">
                      <Icon className="w-4 h-4 text-slate-600 group-hover:text-brand-600 transition-colors" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm font-semibold text-slate-800 group-hover:text-brand-700">{label}</div>
                      <div className="text-xs text-slate-500">{desc}</div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-brand-500 transition-colors" />
                  </Link>
                ))}
              </div>
            </div>

            {/* Recent recommendations */}
            <div className="glass-card p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-display font-semibold text-slate-900 flex items-center gap-2">
                  <Target className="w-4 h-4 text-brand-600" /> Recent Recommendations
                </h3>
                {data?.recs?.length > 0 && (
                  <Link to="/learner/recommendations" className="text-xs text-brand-600 font-semibold hover:underline">
                    View all
                  </Link>
                )}
              </div>
              {!data?.recs?.length ? (
                <div className="text-center py-10">
                  <div className="w-14 h-14 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-3">
                    <Target className="w-7 h-7 text-slate-400" />
                  </div>
                  <p className="text-slate-500 text-sm mb-4">No recommendations yet.<br />Enter your marks to get started!</p>
                  <Link to="/learner/marks" className="btn-primary btn-sm">Enter Marks</Link>
                </div>
              ) : (
                <div className="space-y-2">
                  {data.recs.slice(0, 4).map(r => (
                    <div key={r.recommendation_id} className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 transition-colors">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-slate-800 truncate">{r.programme?.name}</p>
                        <p className="text-xs text-slate-500">{r.programme?.institution?.abbreviation} · APS {r.programme?.aps_requirement}</p>
                      </div>
                      <span className={`badge shrink-0 ${
                        r.status === 'accepted' ? 'badge-success' :
                        r.status === 'applied'  ? 'badge-info' :
                        r.status === 'rejected' ? 'badge-danger' : 'badge-neutral'
                      }`}>{r.status}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </AppShell>
  );
}
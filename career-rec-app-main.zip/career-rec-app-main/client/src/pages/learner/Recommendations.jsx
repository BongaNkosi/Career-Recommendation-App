import { useState, useEffect } from 'react';
import { AppShell } from '../../components/layout/AppShell';
import api from '../../api';
import { useToast } from '../../hooks/useToast';
import { ToastContainer } from '../../components/ui/Toast';
import { Target, Zap, ExternalLink, CheckCircle, Clock, XCircle, Send, Eye, RefreshCw, GraduationCap, Building2 } from 'lucide-react';

const YEAR = new Date().getFullYear();

const STATUS_CONFIG = {
  generated: { label: 'New',      cls: 'badge-neutral', icon: Clock },
  viewed:    { label: 'Viewed',   cls: 'badge-info',    icon: Eye },
  applied:   { label: 'Applied',  cls: 'badge-brand',   icon: Send },
  accepted:  { label: 'Accepted', cls: 'badge-success', icon: CheckCircle },
  rejected:  { label: 'Rejected', cls: 'badge-danger',  icon: XCircle },
};

const FIELD_COLORS = {
  'Engineering & Technology':      'bg-blue-100 text-blue-700',
  'Health Sciences':               'bg-red-100 text-red-700',
  'Business & Management':         'bg-amber-100 text-amber-700',
  'Natural Sciences':              'bg-green-100 text-green-700',
  'Humanities & Social Sciences':  'bg-purple-100 text-purple-700',
  'Law':                           'bg-orange-100 text-orange-700',
  'Education':                     'bg-teal-100 text-teal-700',
  'Agriculture':                   'bg-lime-100 text-lime-700',
  'Arts & Design':                 'bg-pink-100 text-pink-700',
  'Information Technology':        'bg-sky-100 text-sky-700',
};

export default function Recommendations() {
  const { toasts, toast, removeToast } = useToast();
  const [recs,       setRecs]       = useState([]);
  const [loading,    setLoading]    = useState(true);
  const [generating, setGenerating] = useState(false);
  const [updating,   setUpdating]   = useState(null);
  const [filter,     setFilter]     = useState('all');
  const [year,       setYear]       = useState(YEAR);

  const fetchRecs = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/recommendations');
      setRecs(data);
    } catch { toast.error('Failed to load recommendations.'); }
    finally  { setLoading(false); }
  };

  useEffect(() => { fetchRecs(); }, []);

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      const { data } = await api.post('/recommendations/generate', { academic_year: year });
      toast.success(data.message);
      await fetchRecs();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to generate recommendations.');
    } finally {
      setGenerating(false);
    }
  };

  const handleStatus = async (recId, status) => {
    setUpdating(recId);
    try {
      await api.patch(`/recommendations/${recId}/status`, { status });
      setRecs(prev => prev.map(r => r.recommendation_id === recId ? { ...r, status } : r));
      toast.success(`Status updated to "${status}".`);
    } catch { toast.error('Failed to update status.'); }
    finally  { setUpdating(null); }
  };

  const filtered = filter === 'all' ? recs : recs.filter(r => r.status === filter);

  return (
    <AppShell>
      <div className="page-header">
        <div>
          <h1 className="page-title">My Recommendations</h1>
          <p className="page-subtitle">{recs.length} programmes matched to your APS score</p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <select className="form-input !w-auto" value={year} onChange={e => setYear(parseInt(e.target.value))}>
            {[YEAR, YEAR-1, YEAR-2].map(y => <option key={y} value={y}>{y}</option>)}
          </select>
          <button onClick={handleGenerate} disabled={generating} className="btn-primary">
            {generating
              ? <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Generating…</>
              : <><Zap className="w-4 h-4" /> Generate Recommendations</>
            }
          </button>
        </div>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2 mb-6 flex-wrap">
        {['all', 'generated', 'viewed', 'applied', 'accepted', 'rejected'].map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all capitalize ${
              filter === f
                ? 'bg-brand-600 text-white shadow-sm'
                : 'bg-white text-slate-600 border border-slate-200 hover:border-brand-300 hover:text-brand-600'
            }`}
          >
            {f === 'all' ? `All (${recs.length})` : `${f} (${recs.filter(r => r.status === f).length})`}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48"><div className="spinner" /></div>
      ) : filtered.length === 0 ? (
        <div className="glass-card p-14 text-center">
          <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Target className="w-8 h-8 text-slate-400" />
          </div>
          <h3 className="font-display text-lg font-semibold text-slate-700 mb-2">
            {recs.length === 0 ? 'No recommendations yet' : 'No results for this filter'}
          </h3>
          <p className="text-slate-500 text-sm mb-5">
            {recs.length === 0
              ? 'Enter your subject marks, then click "Generate Recommendations" to see matched programmes.'
              : 'Try a different filter tab above.'
            }
          </p>
          {recs.length === 0 && (
            <button onClick={handleGenerate} disabled={generating} className="btn-primary">
              <Zap className="w-4 h-4" /> Generate Now
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5 animate-fade-in">
          {filtered.map(rec => {
            const prog = rec.programme;
            const inst = prog?.institution;
            const status = STATUS_CONFIG[rec.status] || STATUS_CONFIG.generated;
            const StatusIcon = status.icon;
            const matchPct = parseFloat(rec.match_percentage || 0);
            const fieldColor = FIELD_COLORS[prog?.field] || 'bg-slate-100 text-slate-600';

            return (
              <div key={rec.recommendation_id}
                className="glass-card p-5 flex flex-col gap-4 hover:shadow-card-hover hover:-translate-y-0.5 transition-all duration-200">
                {/* Header */}
                <div className="flex items-start justify-between gap-3">
                  <div className="w-10 h-10 bg-navy-900/5 rounded-xl border border-slate-200 flex items-center justify-center shrink-0">
                    <GraduationCap className="w-5 h-5 text-navy-700" />
                  </div>
                  <span className={`badge ${status.cls} shrink-0`}>
                    <StatusIcon className="w-3 h-3" />
                    {status.label}
                  </span>
                </div>

                {/* Programme info */}
                <div className="flex-1">
                  <h4 className="font-display font-semibold text-slate-900 text-sm leading-snug mb-1">
                    {prog?.name}
                  </h4>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-3">
                    <Building2 className="w-3 h-3" />
                    <span>{inst?.name}</span>
                    {inst?.province && <span>· {inst.province}</span>}
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    <span className={`badge text-xs ${fieldColor}`}>{prog?.field}</span>
                    <span className="badge badge-neutral">APS {prog?.aps_requirement}</span>
                    <span className="badge badge-neutral">{prog?.duration_years}yr</span>
                  </div>
                </div>

                {/* Match bar */}
                <div>
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="text-slate-500">Match score</span>
                    <span className="font-bold text-brand-600">{matchPct.toFixed(0)}%</span>
                  </div>
                  <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-brand-600 to-brand-400 rounded-full"
                      style={{ width: `${Math.min(100, matchPct)}%` }}
                    />
                  </div>
                </div>

                {/* Status controls */}
                <div className="flex gap-2 pt-1 border-t border-slate-100">
                  <select
                    value={rec.status}
                    disabled={updating === rec.recommendation_id}
                    onChange={e => handleStatus(rec.recommendation_id, e.target.value)}
                    className="form-input !py-1.5 !text-xs flex-1"
                  >
                    {Object.entries(STATUS_CONFIG).map(([val, cfg]) => (
                      <option key={val} value={val}>{cfg.label}</option>
                    ))}
                  </select>
                  {inst?.website && (
                    <a href={inst.website} target="_blank" rel="noreferrer"
                      className="btn-secondary btn-sm px-2.5 shrink-0">
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </AppShell>
  );
}

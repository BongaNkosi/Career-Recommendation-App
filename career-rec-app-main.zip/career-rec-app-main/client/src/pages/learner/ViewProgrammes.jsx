import { useState, useEffect } from 'react';
import { AppShell } from '../../components/layout/AppShell';
import api from '../../api';
import { Search, Filter, ExternalLink, GraduationCap, Building2, X } from 'lucide-react';

const FIELDS = [
  'Engineering & Technology','Health Sciences','Business & Management',
  'Natural Sciences','Humanities & Social Sciences','Law',
  'Education','Agriculture','Arts & Design','Information Technology',
];
const FIELD_COLORS = {
  'Engineering & Technology':      'bg-blue-100 text-blue-700',
  'Health Sciences':               'bg-red-100 text-red-700',
  'Business & Management':         'bg-amber-100 text-amber-700',
  'Natural Sciences':              'bg-green-100 text-green-700',
  'Humanities & Social Sciences':  'bg-purple-100 text-purple-700',
  'Law':                           'bg-orange-100 text-orange-700',
  'Education':                     'bg-teal-100 text-teal-700',
  'Agriculture':                   'bg-lime-100 text-lime-700',
  'Arts & Design':                 'bg-pink-100 text-pink-700',
  'Information Technology':        'bg-sky-100 text-sky-700',
};

export default function ViewProgrammes() {
  const [programmes, setProgrammes] = useState([]);
  const [loading,    setLoading]    = useState(true);
  const [search,     setSearch]     = useState('');
  const [field,      setField]      = useState('');
  const [minAPS,     setMinAPS]     = useState('');
  const [maxAPS,     setMaxAPS]     = useState('');

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (field)  params.set('field',   field);
    if (minAPS) params.set('min_aps', minAPS);
    if (maxAPS) params.set('max_aps', maxAPS);
    api.get(`/programmes?${params}`).then(r => setProgrammes(r.data)).catch(console.error).finally(() => setLoading(false));
  }, [field, minAPS, maxAPS]);

  const filtered = programmes.filter(p =>
    !search || p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.institution?.name?.toLowerCase().includes(search.toLowerCase())
  );

  const resetFilters = () => { setField(''); setMinAPS(''); setMaxAPS(''); setSearch(''); };
  const hasFilters = field || minAPS || maxAPS || search;

  return (
    <AppShell>
      <div className="page-header">
        <div>
          <h1 className="page-title">Browse Programmes</h1>
          <p className="page-subtitle">{filtered.length} programmes available</p>
        </div>
      </div>

      {/* Filters */}
      <div className="glass-card p-4 mb-6">
        <div className="flex flex-wrap gap-3 items-end">
          <div className="flex-1 min-w-48">
            <label className="form-label text-xs">Search</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input type="text" className="form-input pl-9" placeholder="Programme or institution…"
                value={search} onChange={e => setSearch(e.target.value)} />
            </div>
          </div>
          <div className="min-w-48">
            <label className="form-label text-xs">Field of Study</label>
            <select className="form-input" value={field} onChange={e => setField(e.target.value)}>
              <option value="">All Fields</option>
              {FIELDS.map(f => <option key={f} value={f}>{f}</option>)}
            </select>
          </div>
          <div className="w-24">
            <label className="form-label text-xs">Min APS</label>
            <input type="number" min="0" max="42" className="form-input" placeholder="0"
              value={minAPS} onChange={e => setMinAPS(e.target.value)} />
          </div>
          <div className="w-24">
            <label className="form-label text-xs">Max APS</label>
            <input type="number" min="0" max="42" className="form-input" placeholder="42"
              value={maxAPS} onChange={e => setMaxAPS(e.target.value)} />
          </div>
          {hasFilters && (
            <button onClick={resetFilters} className="btn-ghost text-slate-500 flex items-center gap-1.5">
              <X className="w-4 h-4" /> Clear
            </button>
          )}
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48"><div className="spinner" /></div>
      ) : filtered.length === 0 ? (
        <div className="glass-card p-14 text-center">
          <GraduationCap className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500">No programmes match your filters.</p>
          <button onClick={resetFilters} className="btn-secondary mt-4 btn-sm">Reset Filters</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5 animate-fade-in">
          {filtered.map(prog => (
            <div key={prog.programme_id}
              className="glass-card p-5 flex flex-col gap-3 hover:shadow-card-hover hover:-translate-y-0.5 transition-all duration-200">
              <div className="flex items-start justify-between gap-2">
                <div className="w-10 h-10 bg-navy-900/5 rounded-xl border border-slate-200 flex items-center justify-center shrink-0">
                  <GraduationCap className="w-5 h-5 text-navy-700" />
                </div>
                <span className="badge badge-neutral text-xs">NQF {prog.nqf_level}</span>
              </div>
              <div>
                <h4 className="font-display font-semibold text-slate-900 text-sm leading-snug mb-1">{prog.name}</h4>
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  <Building2 className="w-3 h-3" />
                  <span>{prog.institution?.abbreviation ?? prog.institution?.name}</span>
                  {prog.institution?.province && <span>· {prog.institution.province}</span>}
                </div>
              </div>
              <div className="flex flex-wrap gap-1.5">
                <span className={`badge text-xs ${FIELD_COLORS[prog.field] || 'bg-slate-100 text-slate-600'}`}>{prog.field}</span>
                <span className="badge badge-neutral">APS {prog.aps_requirement}</span>
                <span className="badge badge-neutral">{prog.duration_years} yr{prog.duration_years > 1 ? 's' : ''}</span>
              </div>
              {prog.description && (
                <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">{prog.description}</p>
              )}
              {prog.institution?.website && (
                <a href={prog.institution.website} target="_blank" rel="noreferrer"
                  className="btn-secondary btn-sm self-start mt-auto">
                  <ExternalLink className="w-3.5 h-3.5" /> Visit Website
                </a>
              )}
            </div>
          ))}
        </div>
      )}
    </AppShell>
  );
}

import { CheckCircle, XCircle, AlertTriangle, Info, X } from 'lucide-react';

const icons = {
  success: <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0" />,
  error:   <XCircle    className="w-5 h-5 text-red-500 shrink-0" />,
  warning: <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />,
  info:    <Info       className="w-5 h-5 text-blue-500 shrink-0" />,
};

const styles = {
  success: 'bg-white border-l-4 border-emerald-500',
  error:   'bg-white border-l-4 border-red-500',
  warning: 'bg-white border-l-4 border-amber-500',
  info:    'bg-white border-l-4 border-blue-500',
};

export function ToastContainer({ toasts, onRemove }) {
  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 max-w-sm w-full">
      {toasts.map(t => (
        <div
          key={t.id}
          className={`${styles[t.type]} flex items-start gap-3 px-4 py-3 rounded-xl shadow-lg animate-slide-up`}
        >
          {icons[t.type]}
          <p className="text-sm text-slate-700 font-medium flex-1">{t.message}</p>
          <button onClick={() => onRemove(t.id)} className="text-slate-400 hover:text-slate-600 transition-colors ml-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
}

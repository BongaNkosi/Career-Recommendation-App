import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import {
  LayoutDashboard, BookOpen, FileText, Users, Building2,
  GraduationCap, ClipboardList, BarChart3, LogOut, Target,
} from 'lucide-react';

const adminNav = [
  { to: '/admin',                icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/admin/institutions',   icon: Building2,       label: 'Institutions' },
  { to: '/admin/programmes',     icon: GraduationCap,   label: 'Programmes' },
  { to: '/admin/learners',       icon: Users,           label: 'Learners' },
  { to: '/admin/marks',          icon: ClipboardList,   label: 'Marks' },
  { to: '/admin/reports',        icon: BarChart3,       label: 'Reports' },
];

const learnerNav = [
  { to: '/learner',               icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/learner/marks',         icon: BookOpen,        label: 'My Marks' },
  { to: '/learner/recommendations', icon: Target,        label: 'Recommendations' },
  { to: '/learner/programmes',    icon: FileText,        label: 'Browse Programmes' },
];

export function Sidebar({ mobile, onClose }) {
  const { user, logout, isAdmin } = useAuth();
  const { pathname } = useLocation();
  const navItems = isAdmin ? adminNav : learnerNav;

  const initials = user
    ? `${user.firstName?.[0] ?? ''}${user.lastName?.[0] ?? ''}`.toUpperCase()
    : '?';

  return (
    <aside className={`
      flex flex-col w-64 min-h-screen bg-navy-900 text-white
      ${mobile ? 'fixed inset-y-0 left-0 z-50 shadow-2xl' : 'sticky top-0 h-screen'}
    `}>
      {/* Logo */}
      <div className="px-6 py-6 border-b border-white/10">
        <Link to="/" className="flex items-center gap-3 group" onClick={onClose}>
          <div className="w-9 h-9 rounded-xl bg-brand-600 flex items-center justify-center shrink-0 group-hover:bg-brand-500 transition-colors">
            <GraduationCap className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="font-display font-bold text-lg leading-none">CareerRec</span>
            <p className="text-[10px] text-white/40 uppercase tracking-widest mt-0.5">
              {isAdmin ? 'Admin Panel' : 'Learner Portal'}
            </p>
          </div>
        </Link>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-5 overflow-y-auto scrollbar-hide">
        <ul className="space-y-1">
          {navItems.map(({ to, icon: Icon, label }) => {
            const active = pathname === to;
            return (
              <li key={to}>
                <Link
                  to={to}
                  onClick={onClose}
                  className={`
                    flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all
                    ${active
                      ? 'bg-brand-600/20 text-brand-400 border border-brand-600/30'
                      : 'text-white/60 hover:text-white hover:bg-white/8'
                    }
                  `}
                >
                  <Icon className={`w-4.5 h-4.5 shrink-0 ${active ? 'text-brand-400' : ''}`} />
                  {label}
                  {active && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-brand-400" />}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* User footer */}
      <div className="px-3 py-4 border-t border-white/10">
        <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5 transition-colors">
          <div className="w-8 h-8 rounded-full bg-brand-600/30 border border-brand-600/50 flex items-center justify-center shrink-0">
            <span className="text-xs font-bold text-brand-400">{initials}</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">{user?.firstName} {user?.lastName}</p>
            <p className="text-[11px] text-white/40 truncate">{user?.email}</p>
          </div>
        </div>
        <button
          onClick={logout}
          className="mt-1 flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm font-medium text-white/50 hover:text-red-400 hover:bg-red-400/10 transition-all"
        >
          <LogOut className="w-4 h-4 shrink-0" />
          Sign Out
        </button>
      </div>
    </aside>
  );
}

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { useToast } from './hooks/useToast';
import { ToastContainer } from './components/ui/Toast';
import { ProtectedRoute } from './components/ProtectedRoute';

// Pages
import Home            from './pages/Home';
import Login           from './pages/auth/Login';
import Register        from './pages/auth/Register';
import AdminDashboard  from './pages/admin/Dashboard';
import Institutions    from './pages/admin/Institutions';
import Programmes      from './pages/admin/Programmes';
import Learners        from './pages/admin/Learners';
import AdminMarks      from './pages/admin/Marks';
import Reports         from './pages/admin/Reports';
import LearnerDashboard from './pages/learner/Dashboard';
import EnterMarks       from './pages/learner/EnterMarks';
import Recommendations  from './pages/learner/Recommendations';
import ViewProgrammes   from './pages/learner/ViewProgrammes';

function AuthRedirect({ children }) {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (user) return <Navigate to={user.role === 'admin' ? '/admin' : '/learner'} replace />;
  return children;
}

function AppRoutes() {
  const { toasts, toast, removeToast } = useToast();

  return (
    <>
      <Routes>
        {/* Public */}
        <Route path="/" element={<Home />} />
        <Route path="/login"    element={<AuthRedirect><Login /></AuthRedirect>} />
        <Route path="/register" element={<AuthRedirect><Register /></AuthRedirect>} />

        {/* Admin */}
        <Route path="/admin"                element={<ProtectedRoute role="admin"><AdminDashboard /></ProtectedRoute>} />
        <Route path="/admin/institutions"   element={<ProtectedRoute role="admin"><Institutions /></ProtectedRoute>} />
        <Route path="/admin/programmes"     element={<ProtectedRoute role="admin"><Programmes /></ProtectedRoute>} />
        <Route path="/admin/learners"       element={<ProtectedRoute role="admin"><Learners /></ProtectedRoute>} />
        <Route path="/admin/marks"          element={<ProtectedRoute role="admin"><AdminMarks /></ProtectedRoute>} />
        <Route path="/admin/reports"        element={<ProtectedRoute role="admin"><Reports /></ProtectedRoute>} />

        {/* Learner */}
        <Route path="/learner"                   element={<ProtectedRoute role="learner"><LearnerDashboard /></ProtectedRoute>} />
        <Route path="/learner/marks"             element={<ProtectedRoute role="learner"><EnterMarks /></ProtectedRoute>} />
        <Route path="/learner/recommendations"   element={<ProtectedRoute role="learner"><Recommendations /></ProtectedRoute>} />
        <Route path="/learner/programmes"        element={<ProtectedRoute role="learner"><ViewProgrammes /></ProtectedRoute>} />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}

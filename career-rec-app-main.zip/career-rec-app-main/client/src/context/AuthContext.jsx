import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user,    setUser]    = useState(null);
  const [loading, setLoading] = useState(true);

  // On mount: verify stored token
  useEffect(() => {
    const token = localStorage.getItem('cr_token');
    if (token) {
      api.get('/auth/me')
        .then(res => setUser(res.data))
        .catch(() => { localStorage.removeItem('cr_token'); })
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  /** Login existing user. Returns user object. */
  const login = async (email, password) => {
    const { data } = await api.post('/auth/login', { email, password });
    localStorage.setItem('cr_token', data.token);
    setUser(data.user);
    return data.user;
  };

  /**
   * Register new user — automatically authenticates.
   * Backend returns { token, user } — no redirect to login needed.
   */
  const register = async (payload) => {
    const { data } = await api.post('/auth/register', payload);
    localStorage.setItem('cr_token', data.token);
    setUser(data.user);
    return data.user;
  };

  const logout = () => {
    localStorage.removeItem('cr_token');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{
      user, loading, login, register, logout,
      isAdmin:   user?.role === 'admin',
      isLearner: user?.role === 'learner',
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
